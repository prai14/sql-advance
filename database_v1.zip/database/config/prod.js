module.exports = {
    mySQLHost: 'phototainment360-1424088883.cavz2bunq52b.us-east-1.rds.amazonaws.com', // ClearDB hosts our SQL server
    mySQLUser: 'phototainment360',
    mySQLPassword: 'phototainment360',
    mySQLDatabaseName: 'phototainment360'
};