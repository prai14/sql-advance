var Client = require('mariasql');
var con = require('./connection');

const responseSuccess = {
    statusCode: 200,
    headers: {
        'Access-Control-Allow-Origin': '*', // Required for CORS support to work
    },
    body: JSON.stringify({
        message: 'function executed successfully!'
    }),
};

const responseError = {
    statusCode: 502,
    headers: {
        'Access-Control-Allow-Origin': '*', // Required for CORS support to work
    },
    body: JSON.stringify({
        message: 'no db connection'
    }),
};


exports.execute = function(sql, data, callback) {
    var connection = con.establishConnection();
    connection.query(sql, data, function(err, rows) {
        if (err) {
            responseError.body = err
            callback(responseError, null);
            return;
        }

        responseSuccess.body = JSON.stringify(rows);
        callback(null, responseSuccess);
    });

    connection.end();
};