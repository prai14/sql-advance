var Client = require('mariasql');

exports.establishConnection = function() {
    var c = new Client({

        host: 'phototainment360-1424088883.cavz2bunq52b.us-east-1.rds.amazonaws.com',
        user: 'phototainment360',
        password: 'phototainment360',
        db: 'phototainment360'
    });
    return c;
};