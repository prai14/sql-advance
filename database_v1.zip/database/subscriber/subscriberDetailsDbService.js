var Client = require('mariasql');
var keys = require('../config/keys');
var queries = require('./queries/statement');
var excute = require('../mariadbcon/execureQuery');


module.exports = {
    insertsubscriberDetails: function(data, callback) {
        var sql = queries.insertsubscriberDetails;
        excute.execute(sql, data, callback);
    },

    /* Retrieves a User model by ID */
    getSubscriberDetailsById: function(id, callback) {
        var sql = queries.getSubscriberDetailsById;
        excute.execute(sql, { 'id': id }, callback);
    },

    updatesubscriberDetails: function(user, callback) {
        var sql = queries.updateSubscriberDetails;
        excute.execute(sql, user, callback);
    },

    deletesubscriberDetails: function(id, callback) {
        var sql = queries.deleteSubscriberDetails;
        excute.execute(sql, { 'id': id }, callback);
    }
}