var Client = require('mariasql');
var keys = require('../config/keys');
var queries = require('./queries/statement');
var excute = require('../mariadbcon/execureQuery');

module.exports = {
    insertSubscriber: function(data, callback) {
        var sql = queries.insertSubscriber;
        excute.execute(sql, data, callback);
    },

    /* Retrieves a User model by ID */
    getSubscriberById: function(id, callback) {
        var sql = queries.getSubscriberById;
        excute.execute(sql, { 'id': id }, callback);
    },

    updateSubscriber: function(user, callback) {
        var sql = queries.updateSubscriber;
        excute.execute(sql, user, callback);
    },

    deleteSubscriber: function(id, callback) {
        var sql = queries.deleteSubscriber;
        excute.execute(sql, { 'id': id }, callback);
    }
}