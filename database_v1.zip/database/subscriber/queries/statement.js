module.exports.insertSubscriber = require('./subscriber/insert-subscriber');
module.exports.getSubscriberById = require('./subscriber/get-subscriber-by-id');
module.exports.deleteSubscriber = require('./subscriber/delete-subscriber-by-id');
module.exports.updateSubscriber = require('./subscriber/update-subscriber');


module.exports.insertsubscriberDetails = require('./subscriber_details/insert-subscriber-details');
module.exports.getSubscriberDetailsById = require('./subscriber_details/get-subscriber-detailS-by-id');
module.exports.deleteSubscriberDetails = require('./subscriber_details/delete_subscriber_details_by-id');
module.exports.updateSubscriberDetails = require('./subscriber_details/update-subscriber-details');

module.exports.insertSubscriberPage = require('./subscriber_page/insert-subscriber-page');
module.exports.getSubscriberPageById = require('./subscriber_page/get-subscriber-page-by-id');
module.exports.deleteSubscriberPage = require('./subscriber_page/delete-subscriber-page-by-id');
module.exports.updateSubscriberPage = require('./subscriber_page/update-subscriber-page');