module.exports =
    `SELECT * 
    FROM subscriber_page 
    WHERE id = :id`;