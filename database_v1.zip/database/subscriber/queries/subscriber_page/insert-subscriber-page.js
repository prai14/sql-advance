module.exports =
    `INSERT INTO subscriber_page
    (
    logo,
    company_name,
    title,
    description, 
    create_time,
    modified_time,
    creator_id,
    modifier_id)
    VALUES(:logo, :CompanyName, :title , 
        :description, now(), null, 1, null)`;