module.exports =
    `UPDATE subscriber_page
    logo = :logo,
    company_name = :companyName,
    title = :title,
    description = :description,
    modified_time = now(),
    modifier_id = :modifierId
    WHERE id = :id`;