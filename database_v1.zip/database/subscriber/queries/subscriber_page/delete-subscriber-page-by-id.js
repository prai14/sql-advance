module.exports =
    `DELETE FROM subscriber_page 
    WHERE id = :id`;