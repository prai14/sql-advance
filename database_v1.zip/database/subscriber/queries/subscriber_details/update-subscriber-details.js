module.exports =
    `UPDATE subscriber_details 
    SET
    addrebss1 = :cAddress,
    address2 = :bAddress,
    city = :city,
    company = :company,
    country_code = :countryCode,
    fax = :fax,
    name = :name,
    phone = :phone,
    state = :state,
    zip = :zip,
    modified_time = now(),
    modifier_id = :modifierId`;