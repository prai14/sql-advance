module.exports =
    `SELECT * 
    FROM subscriber_details 
    WHERE id = :id`;