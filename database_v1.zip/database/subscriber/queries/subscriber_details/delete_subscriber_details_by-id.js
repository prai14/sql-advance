module.exports =
    `DELETE FROM subscriber_details 
    WHERE id = :id`;