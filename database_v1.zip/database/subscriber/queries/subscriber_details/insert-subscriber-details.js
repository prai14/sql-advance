module.exports =
    `INSERT INTO subscriber_details
    (
    address1,
    address2,
    city,
    company,
    country_code,
    fax,
    first_name,
    last_name,
    phone,
    state,
    zip,
    create_time,
    modified_time,
    creator_id,
    modifier_id)
    VALUES( :cAddress , :bAddress , :city , :company , :countryCode ,
         :fax , :firstName , :lastName , :phone , 
         :state , :zip , now() , null , 1 , null)`;