module.exports =
    `DELETE FROM subscriber 
    WHERE id = :id`;