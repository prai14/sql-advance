module.exports =
    `INSERT INTO phototainment360.subscriber
    (
    license_id,
    start_subscription_time,
    duration,
    create_time,
    modified_time,
    creator_id,
    modifier_id)
    VALUES(:licenseId, :startSubscriptionTime, 
        :duration, now(), null, 1, null)`;