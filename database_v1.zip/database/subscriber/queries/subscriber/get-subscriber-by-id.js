module.exports =
    `SELECT * 
    FROM subscriber 
    WHERE id = :id`;