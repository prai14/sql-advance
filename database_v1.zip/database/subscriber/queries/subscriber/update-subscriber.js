module.exports =
    `UPDATE subscriber
    SET
    license_id = :licenseId,
    start_subscription_time = :startSubscriptionTime,
    duration = :duration,
    modified_time = now() ,
    modifier_id :modifierId`;