module.exports.userDbService = require('./user/userDbService');
module.exports.userDetailsDbService = require('./user/userDetailsDbService');

module.exports.imageDbService = require('./image/imageDbService');
module.exports.eventDbService = require('./image/eventDbService');

module.exports.subscriberDbService = require('./subscriber/subscriberDbService');
module.exports.subscriberDetailsDbService = require('./subscriber/subscriberDetailsDbService');
module.exports.subscriberPageDbService = require('./subscriber/subscriberPageDbService');

module.exports.subscriptionTypeDbService = require('./subscription_type/subscriptionTypeDbService');