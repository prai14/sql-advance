module.exports =
    `DELETE FROM folder 
    WHERE id = :id`;