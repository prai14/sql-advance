module.exports =
    `SELECT * 
    FROM image 
    WHERE folder_id = :folderId`;