module.exports =
    `UPDATE image 
    SET 
    folder_id = :newFolderId 
    WHERE folder_id = :folderId`;