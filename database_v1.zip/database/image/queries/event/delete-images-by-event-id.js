module.exports =
    `DELETE 
    FROM image 
    WHERE folder_id = :folderID`;