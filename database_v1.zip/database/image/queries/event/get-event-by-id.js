module.exports =
    `SELECT * 
    FROM folder 
    WHERE id = :id`;