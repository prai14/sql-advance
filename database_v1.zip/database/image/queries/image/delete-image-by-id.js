module.exports =
    `DELETE FROM image 
    WHERE id = :id`;