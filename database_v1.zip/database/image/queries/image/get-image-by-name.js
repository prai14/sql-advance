module.exports =
    `SELECT * 
    FROM image 
    WHERE name = :name`;