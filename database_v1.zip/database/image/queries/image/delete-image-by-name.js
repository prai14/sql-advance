module.exports =
    `DELETE FROM image 
     WHERE name = :name`;