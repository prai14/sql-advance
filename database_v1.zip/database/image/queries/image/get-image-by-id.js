module.exports =
    `SELECT * 
    FROM image 
    WHERE id = :id`;