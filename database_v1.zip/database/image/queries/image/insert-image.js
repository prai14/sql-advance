module.exports =
    `INSERT INTO image
    (
    version,
    file_descriptor,
    user_id,
    folder_id,
    display_name,
    name,
    type,
    mime_type,
    create_time,
    modified_time,
    creator_id,
    modifier_id)
    VALUES (:version, :fileDescriptor, :userId , 
        :folderId , :displayName, :name, :type, 
        :mimeType , now(), null, 
        1, null)`;