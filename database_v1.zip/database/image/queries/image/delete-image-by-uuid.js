module.exports =
    `DELETE FROM image 
    WHERE uuid = :uuid`;