module.exports =
    `SELECT * 
    FROM image 
    WHERE uuid = :uuid`;