module.exports.insertImage = require('./image/insert-image');
module.exports.insertEvent = require('./event/insert-event');

module.exports.getImageById = require('./image/get-image-by-id');
module.exports.getImageByName = require('./image/get-image-by-name');
module.exports.getImageByuuid = require('./image/get-image-by-uuid');
module.exports.getEventByID = require('./event/get-event-by-id');
module.exports.getImagesByEventId = require('./event/get-images-by-event-id');

module.exports.deleteImageById = require('./image/delete-image-by-id');
module.exports.deleteImageByName = require('./image/delete-image-by-name');
module.exports.deleteImageByUuid = require('./image/delete-image-by-uuid');
module.exports.deleteEventById = require('./event/delete-event-by-id');
module.exports.deleteImagesByEventId = require('./event/delete-images-by-event-id');

module.exports.updateImage = require('./image/update-image');
module.exports.updateEvent = require('./event/update-event');
module.exports.updateImagesByEventId = require('./event/update-images-by-event-id');