var Client = require('mariasql');
var keys = require('../config/keys');
let eventQueries = require('./queries/statement');
var excute = require('../mariadbcon/execureQuery');


module.exports = {
    insertEvent: function(data, callback) {
        var sql = eventQueries.insertEvent;
        excute.execute(sql, data, callback);
    },

    /* Retrieves a User model by ID */
    getEventByID: function(id, callback) {
        var sql = eventQueries.getEventByID;
        excute.execute(sql, { 'id': id }, callback);
    },

    getImagesByEventId: function(eventId, callback) {
        var sql = eventQueries.getImagesByEventId;
        excute.execute(sql, { 'folder_id': eventId }, callback);
    },

    deleteEventById: function(id, callback) {
        var sql = eventQueries.deleteEventById;
        excute.execute(sql, { 'id': id }, callback);
    },

    deleteImagesByEventId: function(id, callback) {
        var sql = eventQueries.deleteImagesByEventId;
        excute.execute(sql, { 'folder_id': id }, callback);
    },

    updateEvent: function(id, callback) {
        var sql = eventQueries.updateEvent;
        excute.execute(sql, { 'id': id }, callback);
    },

    updateImagesByEventId: function(id, newId, callback) {
        var sql = eventQueries.updateImagesByEventId;
        excute.execute(sql, { 'folder_id': id, 'newFolderId': newId }, callback);
    }


}