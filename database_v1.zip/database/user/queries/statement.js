module.exports.insertUser = require('./user/insert-user');
module.exports.insertUserDeatils = require('./user-details/insert-user-details');

module.exports.getUserByID = require('./user/get-user-by-id');
module.exports.getUserByName = require('./user/get-user-by-name');
module.exports.getUserByEmail = require('./user/get-user-by-email');
module.exports.getUserDetailsById = require('./user-details/get-user-details-by-id');

module.exports.deleteUserByID = require('./user/delete-user-by-id');
module.exports.deleteUserByName = require('./user/delete-user-by-name');
module.exports.deleteUserByEmail = require('./user/delete-user-by-email');
module.exports.deleteUserDetailsById = require('./user-details/delete-user-details-by-id');

module.exports.updatUser = require('./user/update-user');
module.exports.updateUserDetails = require('./user-details/update-user-details');