module.exports =
    `SELECT * 
    FROM user 
    WHERE email = :email`;