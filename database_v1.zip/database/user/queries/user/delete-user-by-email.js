module.exports =
    `DELETE FROM user 
    WHERE email = :email`;