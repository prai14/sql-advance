module.exports =
    `SELECT * 
    FROM user 
    WHERE name = :name`;