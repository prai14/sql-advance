module.exports =
    `INSERT INTO phototainment360.user
(
uuid, 
email, 
name, 
phone, 
status, 
user_details_id,
create_time, 
modified_time, 
creator_id, 
modifier_id)
VALUES(:uuid, :email , :name, :phone , 0, :userDetailsId , now(), null, 1 , null)`;