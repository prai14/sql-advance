module.exports =
    `DELETE FROM user 
     WHERE name = :name`;