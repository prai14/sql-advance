module.exports =
    `UPDATE user
    SET
    uuid  = :uuid , 
    email = :email , 
    name = :name, 
    phone = :phone , 
    status = :status,  
    user_details_id = :userDetailsId, 
    modified_time = now(),
    modifier_id = :modifierID
    WHERE id = :id`;