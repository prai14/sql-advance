module.exports =
    `SELECT * 
    FROM user 
    WHERE id = :id`;