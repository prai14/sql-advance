module.exports =
    `DELETE FROM user 
    WHERE id = :id`;