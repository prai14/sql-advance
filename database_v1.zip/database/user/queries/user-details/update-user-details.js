module.exports =
    `UPDATE user 
    SET
    role_id = :roleId,
    provider_id = :providerId,
    user_group_id = :userGroupId,
    profile_image_id = :profilerImageId,
    subscriber_id = :subscriberId,
    modified_time = now(),
    modifier_id = :modifierId
    WHERE id = :id`;