module.exports =
    `DELETE FROM user-details 
    WHERE id = :id`;