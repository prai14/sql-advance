module.exports =
    `INSERT INTO user_details
    (
    role_id,
    provider_id,
    user_group_id,
    profile_image_id,
    subscriber_id,
    create_time,
    modified_time,
    creator_id,
    modifier_id)
    VALUES( :roleId, 1, 0, :profileImageId , :subscriberId, now(), null, 1 , null)`;