module.exports =
    `SELECT * 
    FROM user_details 
    WHERE id = :id`;