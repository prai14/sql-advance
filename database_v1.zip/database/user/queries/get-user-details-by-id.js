module.exports =
    `SELECT * 
    FROM user-details 
    WHERE id = :id`;