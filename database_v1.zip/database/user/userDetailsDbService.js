var Client = require('mariasql');
var keys = require('../config/keys');
let udQueries = require('./queries/statement');
var excute = require('../mariadbcon/execureQuery');


module.exports = {
    insertUserDetails: function(data, callback) {
        var sql = udQueries.insertUserDeatils;
        excute.execute(sql, data, callback);
    },

    /* Retrieves a User model by ID */
    getUserDetailsByID: function(id, callback) {
        var sql = udQueries.getUserDetailsById;
        excute.execute(sql, { 'id': id }, callback);
    },

    updateUserDetails: function(userDetails, callback) {
        var sql = udQueries.updateUserDetails;
        excute.execute(sql, userDetails, callback);
    },

    deleteUserDetailsByID: function(id, callback) {
        var sql = udQueries.deleteUserDetailsById;
        excute.execute(sql, { 'id': id }, callback);
    }
}