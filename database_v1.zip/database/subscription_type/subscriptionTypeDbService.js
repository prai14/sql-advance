var Client = require('mariasql');
var keys = require('../config/keys');
var queries = require('./queries/statement');
var excute = require('../mariadbcon/execureQuery');


module.exports = {
    insertSubscriptionType: function(data, callback) {
        var sql = queries.insertSubscriptionType;
        excute.execute(sql, data, callback);
    },

    /* Retrieves a User model by ID */
    getSubscriptionType: function(id, callback) {
        var sql = queries.getSubscriptionType;
        excute.execute(sql, { 'id': id }, callback);
    },

    deleteSubscriptionType: function(id, callback) {
        var sql = queries.deleteSubscriptionType;
        excute.execute(sql, { 'id': id }, callback);
    },

    updateSubscriptionType: function(data, callback) {
        var sql = queries.updateSubscriptionType;
        excute.execute(sql, data, callback);
    }
}