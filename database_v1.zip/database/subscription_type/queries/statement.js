module.exports.insertSubscriptionType = require('./subscription_type/insert-subscription_type');
module.exports.getSubscriptionType = require('./subscription_type/get-subscription_type-by-id');
module.exports.deleteSubscriptionType = require('./subscription_type/delete-subscription_type-by-id');
module.exports.updateSubscriptionType = require('./subscription_type/update-subscription_type');