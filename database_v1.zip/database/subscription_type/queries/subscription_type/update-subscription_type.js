module.exports =
    `UPDATE subscription_type 
    SET
    version = :version,
    type = :type,
    validity = :validity,
    payment_amount = :paymentAmount,
    modified_time = now(),
    modifier_id = :modifierId
    WHERE id = :Id`;