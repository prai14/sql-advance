module.exports =
    `DELETE FROM subscription_type 
    WHERE id = :id`;