module.exports =
    `INSERT INTO subscription_type
    (
    version,
    type,
    validity,
    payment_amount,
    create_time,
    creator_id,
    modifier_id)
    VALUES(1, :type, :validity , :paymentAmount, now(), 1, null)`;