module.exports =
    `SELECT * 
    FROM subscription_type 
    WHERE id = :id`;