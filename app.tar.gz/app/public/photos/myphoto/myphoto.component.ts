import { BaseComponent, IBaseComponent } from '../../../shared/base.component';
import { isNullOrUndefined } from 'util';
import { UserLoginService } from '../../../service/user-login.service';
const uuidv4 = require('uuid/v4');

import { UserService } from '../../../service/sql-db/user.service';
import { environment } from '../../../../environments/environment';
import { S3Service } from '../../../service/s3.service';
import { Component, OnInit, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { IImage, Image, ImageInfo } from '../../../models/image-info';
import { ImageService } from '../../../service/sql-db/image.service';
import { ApiControllerService } from '../../../service/api-controller.service';
import { Event, IEvent } from '../../../models/event';
import * as S3 from 'aws-sdk/clients/s3';
import { Callback, ChallengeParameters, CognitoCallback, LoggedInCallback } from '../../../service/cognito.service';
import * as _ from 'underscore';
import { PagerService } from '../../../service/pager.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Scene } from 'angular-vrviewer/scene.interface';
import { VRViewModule } from 'angular-vrviewer';
//import { VRViewModule } from 'angular-vrviewer';


@Component({
  selector: 'app-myphoto',
  templateUrl: './myphoto.component.html',
  styleUrls: ['./myphoto.component.css']
})
export class MyphotoComponent extends BaseComponent implements IBaseComponent, OnInit {
  value;
  eventName;
  selectedFile: FileList;
  eventId = 0;
  imageInfoList: IImage[];
  eventInfoList: IEvent[];
  userName: string;
  loading = false;
  noOfImages: number;
  noOfEvents: number;
  alertMsg: string;

    // array of all items to be paged
    private allItems: any[];

    // pager object
    pager: any = {};

    // paged items
    pagedItems: any[];

    scenes: Scene = {
  };

  ngOnInit() {
   // this.errorMessage = null;

    this.userService.isAuthenticated(this);
    this.imageInfoList = ImageService.imageList;
    this.eventInfoList = ImageService.eventList;
    this.userName = this.getUserName();

    if (!isNullOrUndefined(ImageService.imageList)){
      this.noOfImages = ImageService.imageList.length;
    }
    if (!isNullOrUndefined(ImageService.eventList)){
      this.noOfEvents = ImageService.eventList.length;
    }
   // this.element = document.getElementById('vrViewId');
  }
  

  cognitoCallback(message: string, result: any) {
    if (message != null) { //error
            this.router.navigate(['/login']);
    } else { //success
      this.startLoadingData();
    }
  }

  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {
  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
      if (isLoggedIn) {
        this.startLoadingData();
      }
  }

  cancelMFA(): boolean {
      return false;   //necessary to prevent href navigation
  }

  uploadPhoto(file: File) {
    this.imageService.uploadPhoto(UserService.selectedUser.id, 
      this.eventId, file, (err, data, image) => {
      if (err) {
         console.log('Error::', err);
      } else {
        console.log(data);
         console.log(image);
         this.imageService.updateThumbnail(image);
         image.thumbnail = image.url;
         this.imageInfoList.push(image);
      }
    });
  }

  uploadSelectedPhoto() {
    console.log('uploading files');
    for (let i = 0; i < this.selectedFile.length; i++) {
      console.log(this.selectedFile[i]);
      this.uploadPhoto(this.selectedFile[i]);
    }
  }

  updateFileSelection(input) {
    console.log('file selected>>--');
    console.log(input.target.files);
    this.selectedFile = input.target.files as FileList;
  }

  addEvent(userId: number, eventName: string) {
    const event: IEvent = new Event();
    event.userId = userId;
    event.name = eventName;

    this.apiController.addEvent(userId, event).subscribe(data => {
      event.id = data.info.insertId;
      this.eventInfoList.push(event);
     });
  }

  show360DegreeViw(url) {
    document.getElementById('modal01').style.display='block';
         var path = url;        
/* 
         this.vrViewModule.setContent({
          image: path,          
          is_autopan_off: false
         }); */
    this.scenes = {
      world: {
        image: path,
        hotspots: {
          green_area: {
            pitch: 10,
            yaw: -15,
            radius: 0.05,
            distance: 1
          },
        }
      },
      green_area: {
        image: path,
        hotspots: {
          world: {
            pitch: 20,
            yaw: 0,
            radius: 0.05,
            distance: 1
          },
        }
      }
    };
  }

  createEvent() {
    let uid = UserService.selectedUser.id;
    this.eventName = this.value;
        if(this.eventName == " " || this.eventName == null || this.eventName == "undefined"){
      this.alertMsg="Event field can't be empty";
    } else {
    this.addEvent(uid, this.eventName);
      console.log(this.value);
    }
  }
  insideEvent(eventId, eventName){
    this.router.navigate(['/' +  this.apiController.getUserName() + '/agency-event/' + eventId])
  }
}
