import { BaseComponent, IBaseComponent } from '../../../shared/base.component';
import { isNullOrUndefined } from 'util';
import { UserService } from '../../../service/sql-db/user.service';
import { User } from 'aws-sdk/clients/iam';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { ImageInfo, IImage } from '../../../models/image-info';
import { ImageService } from '../../../service/sql-db/image.service';
import { ApiControllerService } from '../../../service/api-controller.service';
import { S3Service } from '../../../service/s3.service';
import { UserLoginService } from '../../../service/user-login.service';
import { ChallengeParameters } from '../../../service/cognito.service';
import { Scene } from 'angular-vrviewer/scene.interface';

@Component({
  selector: 'agency-event',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent extends BaseComponent implements IBaseComponent, OnInit {
  selectedFile: FileList;
  eventId: number;
  private sub: any;
  scenes: Scene = {
  };

  ngOnInit() {
    const self = this;
    this.sub = this.route.params.subscribe(params => {
      this.eventId = params['id'];
    });

    const loc = window.location;
    this.userName = loc.pathname.substring(1, loc.pathname.indexOf('/', 1));

    if (isNullOrUndefined(this.eventId)) {
          this.eventId = +loc.pathname.substring(loc.pathname.lastIndexOf('/'));
    }

    this.userService.isAuthenticated(this);
  }

  cognitoCallback(message: string, result: any) {
    if (message != null) { 
       this.router.navigate(['/login']);
    } else {
    }
  }

  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {
  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
      if (isLoggedIn) {
        this.startLoadingData();
      }
  }

  cancelMFA(): boolean {
      return false;   //necessary to prevent href navigation
  }
 

  uploadPhoto(file: File) {
    this.imageService.uploadPhoto(UserService.selectedUser.id, this.eventId,
       file, (err, data, image) => {
      if (err) {
         console.log('Error::', err);
      } else {
          this.imageService.updateThumbnail(image);
          image.thumbnail = image.url;
          this.imageInfoList.push(image);
      }
    });
  }

  uploadSelectedPhoto() {
    console.log('uploading files');
    for (let i = 0; i < this.selectedFile.length; i++) {
      console.log(this.selectedFile[i]);
      this.uploadPhoto(this.selectedFile[i]);
    }
  }

  updateFileSelection(input) {
    console.log('file selected>>--');
    console.log(input.target.files);
    this.selectedFile = input.target.files as FileList;
  }

  show360DegreeViw(url) {
  }
}
