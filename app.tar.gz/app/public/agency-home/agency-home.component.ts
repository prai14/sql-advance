import { BaseHomeComponent } from '../../shared/base.component';
import { isNullOrUndefined } from 'util';
import { IEvent } from '../../models/event';
import { SubscriberService } from '../../service/sql-db/subscriber.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { IImage, ImageInfo } from '../../models/image-info';
import { ImageService } from '../../service/sql-db/image.service';
import { ApiControllerService } from '../../service/api-controller.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { ISubscriberPage } from '../../models/subscriber-page-info';
import { Scene } from 'angular-vrviewer/scene.interface';

@Component({
  selector: 'app-agency-home',
  templateUrl: './agency-home.component.html',
  styleUrls: ['./agency-home.component.css']
})
export class AgencyHomeComponent extends BaseHomeComponent implements OnInit {
  eventId = '0';
  private sub: any;
  scenes: Scene = {};

  ngOnInit() {
    this.showHeader =false;
    const loc = window.location;
    this.userName = loc.pathname.substring(1, loc.pathname.indexOf('/', 1));
    this.sub = this.route.params.subscribe(params => {
      this.eventId = params['id'];
      if (!isNullOrUndefined(ImageService.imageList)) {
        this.imageInfoList = ImageService.imageList;
         this.eventInfoList = ImageService.eventList;
         this.noOfEvents = ImageService.eventList.length;
         this.noOfImages = ImageService.imageList.length;
         this.home = SubscriberService.userSubscriberInfo.subscriberPage;
         document.getElementById('agencyNav').style.backgroundColor = this.home.headerBgColor;
         document.getElementById('homeBody').style.backgroundColor = SubscriberService.userSubscriberInfo.subscriberPage.bodyBgColor;
         document.getElementById('companyTitle').style.color = this.home.headerTextColor;
         document.getElementById('companyDesc').style.color = this.home.headerTextColor;
      
         if(this.home.logoPosition == 1){
          this.logoPositionLeft();
        }
        else if(this.home.logoPosition == 2){
          this.logoPositionRight();
        }
      //   this.setBodyPattern(this.home.bodyBgPattern);
      }
    });
      this.loadUserInfo();
//    }

  }

  loadUserInfo() {
    this.startLoadingData();
  }

  onLoadSubscriberInfo(err, data){
    this.spinner.hide();
    if (err) {
        console.log('Error on: onLoadUser');
    }

    if (!isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
        this.subscriberInfo = SubscriberService.userSubscriberInfo;
        this.subscriberInfo.createTime = SubscriberService.userSubscriberInfo.createTime;
        this.subscriptionType = SubscriberService.userSubscriberInfo.licenseId;
        console.log('on: onLoadSubscriberInfo');
        console.log(this.subscriptionType);
        document.getElementById('agencyNav').style.backgroundColor = SubscriberService.userSubscriberInfo.subscriberPage.headerBgColor;
        document.getElementById('homeBody').style.backgroundColor = SubscriberService.userSubscriberInfo.subscriberPage.bodyBgColor;
        document.getElementById('companyTitle').style.color = this.home.headerTextColor;
        document.getElementById('companyDesc').style.color = this.home.headerTextColor;
     
        if(this.home.logoPosition == 1){
          this.logoPositionLeft();
        }
        else if(this.home.logoPosition == 2){
          this.logoPositionRight();
        }
        //  this.setBodyPattern(this.home.bodyBgPattern);
        //  myThis.userName = myThis.apiController.getUserName();
    }
}
  show360DegreeViw(url) {
    
    this.scenes = {
      world: {
        image: url,
        hotspots: {
          green_area: {
            pitch: 10,
            yaw: -15,
            radius: 0.05,
            distance: 1
          },
        }
      },
      green_area: {
        image: url,
        hotspots: {
          world: {
            pitch: 20,
            yaw: 0,
            radius: 0.05,
            distance: 1
          },
        }
      }
  };
  }
  setHeaderPattern(patternId){
    document.getElementById('agencyNav').style.backgroundImage = 'url(assets/img/patt'+ patternId +'.jpg)';
    this.home.headerBgPattern = patternId;
  }
  setBodyPattern(patternId){
    document.getElementById('homePreview').style.backgroundImage = 'url(assets/img/patt'+ patternId +'.jpg)';
    document.getElementById('patt' + patternId).getAttribute('checked'); 
    this.home.bodyBgPattern = patternId;
  }
  logoPositionLeft(){
    document.getElementById('logoContent').style.cssFloat = 'left';
    document.getElementById('descContent').style.cssFloat = 'right';
    this.home.logoPosition = 1;
   // document.getElementById('leftRadio').setAttribute('value','true');
   // document.getElementById('rightRadio').setAttribute('value','false');
   //val.checked = true;
  
  }
  logoPositionRight(){
    document.getElementById('logoContent').style.cssFloat = 'right';
    document.getElementById('descContent').style.cssFloat = 'left';
    this.home.logoPosition = 2;
   // document.getElementById('rightRadio').setAttribute('value','true');
   // document.getElementById('leftRadio').setAttribute('value','false');
    //document.getElementById('rightRadio').setAttribute('value','false');
    
  }
}
