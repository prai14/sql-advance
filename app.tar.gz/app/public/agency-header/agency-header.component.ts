import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'agency-header',
  templateUrl: './agency-header.component.html',
  styleUrls: ['./agency-header.component.css']
})
export class AgencyHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
