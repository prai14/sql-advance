import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserLoginService } from '../../../service/user-login.service';
import { Callback, ChallengeParameters, CognitoCallback, LoggedInCallback } from '../../../service/cognito.service';
import { DynamoDBService } from '../../../service/ddb.service';
import { UserService } from '../../../service/sql-db/user.service';
import { ApiControllerService } from '../../../service/api-controller.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';



@Component({
    selector: 'awscognito-angular2-app',
    templateUrl: './login.html',
    styleUrls: ['./login.css']
})
export class LoginComponent implements CognitoCallback, LoggedInCallback, OnInit {
    email: string;
    password: string;
    errorMessage: string;
    mfaStep = false;
    mfaData = {
        destination: '',
        callback: null
    };

    constructor(public router: Router,
        public userService: UserLoginService,
        public apiController: ApiControllerService,
    private spinnerService: Ng4LoadingSpinnerService) {
        console.log('LoginComponent constructor');
    }

    ngOnInit() {
        this.apiController.log('LoginComponent');
        this.errorMessage = null;
         this.userService.isAuthenticated(this);
    }

    onLogin() {
        if (this.email == null || this.password == null) {
            this.errorMessage = "All fields are required";
            return;
        }
        document.getElementById("signupSubmit").innerHTML="Logging in...";
        this.errorMessage = null;
       
        this.userService.authenticate(this.email, this.password, this);
    
    }

    cognitoCallback(message: string, result: any) {
       
        if (message != null) { //error
            document.getElementById("signupSubmit").innerHTML="Log In";
            this.errorMessage = message;
            console.log("result: " + this.errorMessage);
            if (this.errorMessage === 'User is not confirmed.') {
                console.log("redirecting");
                this.router.navigate(['/confirmRegistration', this.email]);
            } else if (this.errorMessage === 'User needs to set password.') {
                console.log("redirecting to set new password");
                this.router.navigate(['/newPassword']);
            }
        } else { //success
           
            console.log('login loader ends');
            this.router.navigate(['/'  + this.apiController.getUserName() +
            '/dashboard']);
          
    
        }
    }

    handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {
        this.mfaStep = true;
        this.mfaData.destination = challengeParameters.CODE_DELIVERY_DESTINATION;
        this.mfaData.callback = (code: string) => {
            if (code == null || code.length === 0) {
                this.errorMessage = "Code is required";
                return;
            }
            this.errorMessage = null;
            callback(code);
        };
    }

    isLoggedIn(message: string, isLoggedIn: boolean) {
        if (isLoggedIn) {
           
            this.router.navigate(['/'  + this.apiController.getUserName() +
            '/dashboard']);
        }
    }

    cancelMFA(): boolean {
        this.mfaStep = false;
        return false;   //necessary to prevent href navigation
    }
}
