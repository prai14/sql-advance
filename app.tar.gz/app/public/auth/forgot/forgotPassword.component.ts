import {Component, OnDestroy, OnInit} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {UserLoginService} from "../../../service/user-login.service";
import {CognitoCallback} from "../../../service/cognito.service";

@Component({
    selector: 'awscognito-angular2-app',
    templateUrl: './forgotPassword.html',
    styleUrls: ['./forgotPassword.css']
})
export class ForgotPasswordStep1Component implements CognitoCallback {
    email: string;
    errorMessage: string;

    constructor(public router: Router,
                public userService: UserLoginService) {
        this.errorMessage = null;
    }

    onNext() {
        if (this.email == null ) {
            this.errorMessage = "Email field can't be empty";
            return;
        }
        this.errorMessage = null;
        this.userService.forgotPassword(this.email, this);
    }

    cognitoCallback(message: string, result: any) {
        this.router.navigate(['/forgotPassword', this.email]);
        if (message == null && result == null) { //error
            document.getElementById("nextPage").innerHTML = "Next";
        } else { //success
            document.getElementById("nextPage").innerHTML = "Wait...";
            this.errorMessage = message;
        }
    }
}


@Component({
    selector: 'awscognito-angular2-app',
    templateUrl: './forgotPasswordStep2.html',
    styleUrls: ['forgotPassword.css']
})
export class ForgotPassword2Component implements CognitoCallback, OnInit, OnDestroy {

    verificationCode: string;
    email: string;
    password: string;
    errorMessage: string;
    private sub: any;

    constructor(public router: Router, public route: ActivatedRoute,
                public userService: UserLoginService) {
        console.log("email from the url: " + this.email);
    }

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.email = params['email'];

        });
        this.errorMessage = null;
    }

    ngOnDestroy() {
        this.sub.unsubscribe();
    }

    onNext() {
        if (this.email == null || this.verificationCode == null || this.password == null) {
            this.errorMessage = "All fields are required";
            return;
        }
        this.errorMessage = null;
        this.userService.confirmNewPassword(this.email, this.verificationCode, this.password, this);
    }

    cognitoCallback(message: string) {
        if (message != null) { //error
            this.errorMessage = message;
            document.getElementById("signupSubmit").innerHTML = "Reset Password";
            console.log("result: " + this.errorMessage);
        } else { //success
            document.getElementById("signupSubmit").innerHTML = "Resetting password...";
            this.router.navigate(['/login']);
        }
    }

}