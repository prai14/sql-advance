import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { UserRegistrationService } from "../../../service/user-registration.service";
import { CognitoCallback } from "../../../service/cognito.service";
import { ApiControllerService } from "../../../service/api-controller.service";
import { User } from "../../../models/user";

export class RegistrationUser {
    name: string;
    email: string;
    phone_number: string;
    password: string;
}
@Component({
    selector: 'awscognito-angular2-app',
    templateUrl: './registration.html',
    styleUrls: ['./registration.css']
})
export class RegisterComponent implements CognitoCallback {
    registrationUser: RegistrationUser;
    router: Router;
    errorMessage: string;
    public user: any = {
        id: "",
        uuid: "",
        email: "",
        name: "",
        phone: "",
        status: "",
        create_time: "",
        modified_time: null,
        creator_id: "",
        modifier_id: ""
    }

    constructor(public userRegistration: UserRegistrationService, router: Router, public apiController: ApiControllerService) {
        this.router = router;
        this.onInit();
    }

    onInit() {
        this.registrationUser = new RegistrationUser();
        this.errorMessage = null;
    }

    onRegister() {
        if (this.registrationUser.name == null || this.registrationUser.email == null || this.registrationUser.phone_number == null || this.registrationUser.password == null) {
            this.errorMessage = "All fields are required";
            return;
        }
        document.getElementById("signupSubmit").innerHTML="Creating account...";
        this.errorMessage = null;
        this.userRegistration.register(this.registrationUser, this);
    }
    getUser(id: number) {
        this.apiController.getUser(id).subscribe(data => {
            /*   console.log('getUser data:::>' + JSON.stringify(data)); */
            this.user = data;
        });
    }
    addUser(data: RegistrationUser) {
        const newUser: User = {
            id: 1,
            uuid: 1212,
            email: data.email,
            name: data.name,
            phone: data.phone_number,
            status: 1,
            userDetailId : 1
        };

        this.apiController.addUser(newUser).subscribe(data => {
            console.log('add data>>>' + JSON.stringify(data));
            this.getUser(data.info.insertId);
        });
    }

    cognitoCallback(message: string, result: any) {
        if (message != null) { //error
            this.errorMessage = message;
            document.getElementById("signupSubmit").innerHTML="Creating your account";
            console.log("result: " + this.errorMessage);
        } else { //success
            //move to the next step
            this.addUser(this.registrationUser);
            console.log("redirecting");
            this.router.navigate(['/confirmRegistration', result.user.username]);

        }
    }
}
