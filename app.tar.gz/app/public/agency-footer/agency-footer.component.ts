import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'agency-footer',
  templateUrl: './agency-footer.component.html',
  styleUrls: ['./agency-footer.component.css']
})
export class AgencyFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
