import { Component, OnInit } from '@angular/core';
import { ActivatedRoute }       from '@angular/router';
import { Observable }           from 'rxjs/Observable';
import 'rxjs/add/operator/map';


@Component({
  selector: 'app-eventinfo',
  templateUrl: './eventinfo.component.html',
  styleUrls: ['./eventinfo.component.css']
})
export class EventInfoComponent implements OnInit {
  eventId: Observable<string>;
  token: Observable<string>;
//  modules: string[];

  constructor( private route: ActivatedRoute) {
  }

  ngOnInit() {
    // Capture the session ID if available
    this.eventId = this.route
      .queryParamMap
      .map(params => params.get('id') || 'None');

    // Capture the fragment if available
    this.token = this.route
      .fragment
      .map(fragment => fragment || 'None');
  }
}