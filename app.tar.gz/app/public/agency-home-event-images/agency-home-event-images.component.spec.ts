import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyHomeEventImagesComponent } from './agency-home-event-images.component';

describe('AgencyHomeEventImagesComponent', () => {
  let component: AgencyHomeEventImagesComponent;
  let fixture: ComponentFixture<AgencyHomeEventImagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencyHomeEventImagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyHomeEventImagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
