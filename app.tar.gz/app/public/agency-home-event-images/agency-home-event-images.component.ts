import { BaseComponent, IBaseComponent } from '../../shared/base.component';
import { isNullOrUndefined } from 'util';
import { SubscriberService } from '../../service/sql-db/subscriber.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { IImage, ImageInfo } from '../../models/image-info';
import { ImageService } from '../../service/sql-db/image.service';
import { ApiControllerService } from '../../service/api-controller.service';
import { ISubscriberPage } from '../../models/subscriber-page-info';
import { Scene } from 'angular-vrviewer/scene.interface';

@Component({
  selector: 'app-agency-home-event-images',
  templateUrl: './agency-home-event-images.component.html',
  styleUrls: ['./agency-home-event-images.component.css']
})

export class AgencyHomeEventImagesComponent extends BaseComponent 
implements IBaseComponent, OnInit {
  eventId: number;
  scenes: Scene = {};

  private sub: any;

  ngOnInit() {
    const loc = window.location;
    this.userName = loc.pathname.substring(1, loc.pathname.indexOf('/', 1));

    this.sub = this.route.params.subscribe(params => {
      this.eventId = params['id'];
      if (!isNullOrUndefined(ImageService.eventMap) && ImageService.eventMap.get(this.eventId) != null) {
         this.imageInfoList = ImageService.eventMap.get(this.eventId).imageList;
         this.noOfImages = ImageService.eventMap.get(this.eventId).imageList.length;
         this.home = SubscriberService.userSubscriberInfo.subscriberPage;
      }
    });

    if (isNullOrUndefined(this.imageInfoList)) {
      this.loadUserInfo();
    }
  }

  loadUserInfo() {
    this.startLoadingData();
  }

  show360DegreeViw(url) {
  };

  dummy(url){
    this.scenes = {
      world: {
        image: url,
        hotspots: {
          green_area: {
            pitch: 10,
            yaw: -15,
            radius: 0.05,
            distance: 1
          },
        }
      },
      green_area: {
        image: url,
        hotspots: {
          world: {
            pitch: 20,
            yaw: 0,
            radius: 0.05,
            distance: 1
          },
        }
      }
  };
  }

}

