import { InitAppService } from './service/init-app.service';
import { S3Service } from './service/s3.service';
import { ApiControllerService } from './service/api-controller.service';
import {BrowserModule} from "@angular/platform-browser";
import {NgModule} from "@angular/core";
import {FormsModule} from "@angular/forms";
import {HttpModule} from "@angular/http";
import {AppComponent} from "./app.component";
import {UserRegistrationService} from "./service/user-registration.service";
import {UserParametersService} from "./service/user-parameters.service";
import {UserLoginService} from "./service/user-login.service";
import {CognitoUtil} from "./service/cognito.service";
import {routing} from "./app.routes";
import {AboutComponent, HomeComponent, HomeLandingComponent} from "./public/home.component";
import {AwsUtil} from "./service/aws.service";
import {SecureHomeComponent} from "./secure/landing/securehome.component";
import {JwtComponent} from "./secure/jwttokens/jwt.component";
import {DynamoDBService} from "./service/ddb.service";
import {LoginComponent} from "./public/auth/login/login.component";
import {RegisterComponent} from "./public/auth/register/registration.component";
import {ForgotPassword2Component, ForgotPasswordStep1Component} from "./public/auth/forgot/forgotPassword.component";
import {LogoutComponent, RegistrationConfirmationComponent} from "./public/auth/confirm/confirmRegistration.component";
import {ResendCodeComponent} from "./public/auth/resend/resendCode.component";
import {NewPasswordComponent} from "./public/auth/newpassword/newpassword.component";
import { MFAComponent } from './public/auth/mfa/mfa.component';
import { MyphotoComponent } from './public/photos/myphoto/myphoto.component';
import { UploadComponent } from './public/photos/upload/upload.component';
import { HeaderComponent } from './secure/header/header.component';
import { FooterComponent } from './secure/footer/footer.component';
import { UnsuscribDashboardComponent } from './secure/agency/unsuscrib-dashboard/unsuscrib-dashboard.component';
import { SubscribeComponent } from './secure/agency/subscribe/subscribe.component';
import { SubscribePlanComponent } from './secure/agency/subscribe-plan/subscribe-plan.component';
import { agencySecureHomeComponent } from './secure/agency/agency-secure-home/agency-secure-home.component';
import { AgencyAccountComponent } from './secure/agency/agency-account/agency-account.component';
import { agencyComponent } from './secure/agency/agency.component';
import { EventListComponent } from './public/events/eventlist/eventlist.component';
import { EventInfoComponent } from './public/events/eventinfo/eventinfo.component';
import { AdminComponent } from './secure/admin/admin.component';
import { IndexPostSubscriptionFreeComponent } from './secure/agency/index-post-subscription-free/index-post-subscription-free.component';
import { IndexPostSubscriptionPremiumComponent } from './secure/agency/index-post-subscription-premium/index-post-subscription-premium.component';
import { FreeSubscriptionInfoComponent } from './secure/agency/free-subscription-info/free-subscription-info.component';
import { PremiumSubscriptionInfoComponent } from './secure/agency/premium-subscription-info/premium-subscription-info.component';
import { UseractivityComponent } from "./secure/useractivity/useractivity.component";
import { AdminDashboardComponent } from './secure/admin/admin-dashboard/admin-dashboard.component';
import { DashboardComponent } from './secure/dashboard/dashboard.component';
import { AdminAccountComponent } from './secure/admin/admin-account/admin-account.component';
import { AdminSubscriberListUploadsComponent } from './secure/admin/admin-subscriber-list-uploads/admin-subscriber-list-uploads.component';
import { SubscribersListComponent } from './secure/admin/subscribers-list/subscribers-list.component';
import { AdminSubscriberUploadsComponent } from './secure/admin/admin-subscriber-uploads/admin-subscriber-uploads.component';
import { AdminEventImagesComponent } from './secure/admin/admin-event-images/admin-event-images.component';
import { SubscriberInfoComponent } from './secure/admin/subscriber-info/subscriber-info.component';
import { AgencyHomeComponent } from './public/agency-home/agency-home.component';
import { AgencyHomeEventImagesComponent } from './public/agency-home-event-images/agency-home-event-images.component';
import { AgencyHeaderComponent } from './public/agency-header/agency-header.component';
import { AgencyFooterComponent } from './public/agency-footer/agency-footer.component';
import { LandingComponent } from './public/landing/landing.component';
import { AdminAccount } from "./models/admin-account";
import { HttpClientModule } from "@angular/common/http";
import { UserService } from './service/sql-db/user.service';
import { ImageService } from "./service/sql-db/image.service";
import { SubscriberService } from "./service/sql-db/subscriber.service";
import { MessageService } from "./service/sql-db/message.service";
import { PagerService } from './service/pager.service';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { VRViewModule } from 'angular-vrviewer';
import { AdminService } from './service/sql-db/admin.service';



@NgModule({
    declarations: [
        NewPasswordComponent,
        LoginComponent,
        LogoutComponent,
        RegistrationConfirmationComponent,
        ResendCodeComponent,
        ForgotPasswordStep1Component,
        ForgotPassword2Component,
        RegisterComponent,
        MFAComponent,
        AboutComponent,
        HomeLandingComponent,
        HomeComponent,
        SecureHomeComponent,
        JwtComponent,
        AppComponent,
        MyphotoComponent,
        UploadComponent,
        HeaderComponent,
        FooterComponent,
        UnsuscribDashboardComponent,
        SubscribeComponent,
        SubscribePlanComponent,
        agencySecureHomeComponent,
        AgencyAccountComponent,
        agencyComponent,
        EventListComponent,
        EventInfoComponent,
        AdminComponent,
        IndexPostSubscriptionFreeComponent,
        IndexPostSubscriptionPremiumComponent,
        FreeSubscriptionInfoComponent,
        PremiumSubscriptionInfoComponent,
        UseractivityComponent,
        AdminDashboardComponent,
        DashboardComponent,
        AdminAccountComponent,
        AdminSubscriberListUploadsComponent,
        SubscribersListComponent,
        AdminSubscriberUploadsComponent,
        AdminEventImagesComponent,
        SubscriberInfoComponent,
        AgencyHomeComponent,
        AgencyHomeEventImagesComponent,
        AgencyHeaderComponent,
        AgencyFooterComponent,
        LandingComponent,
   
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        routing,
        HttpClientModule,
        Ng4LoadingSpinnerModule.forRoot(),
        VRViewModule
      
    ],
    providers: [
        S3Service,
        CognitoUtil,
        AwsUtil,
        DynamoDBService,
        UserRegistrationService,
        UserLoginService,
        UserService,
        ImageService,
        SubscriberService,
        MessageService,
        UserParametersService,
        ApiControllerService,
        PagerService,
        InitAppService,
        AdminService],
    bootstrap: [AppComponent]
})
export class AppModule {
}
