import { AdminService } from '../service/sql-db/admin.service';
import { AgencyAccount, IAgencyAccount } from '../models/agency-account';
import { ISubscriberDetails } from '../models/subscriber-details';
import { InitAppService } from '../service/init-app.service';
import { UserLoginService } from '../service/user-login.service';
import { ISubscriber, Subscriber } from '../models/subscriber';
import { User, IUser } from '../models/user';
import { isNullOrUndefined } from 'util';
import { IEvent } from '../models/event';
import { SubscriberService } from '../service/sql-db/subscriber.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { IImage, ImageInfo } from '../models/image-info';
import { ImageService } from '../service/sql-db/image.service';
import { UserService } from '../service/sql-db/user.service';
import { ApiControllerService } from '../service/api-controller.service';
import { Ng4LoadingSpinnerService, Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ISubscriberPage } from '../models/subscriber-page-info';
import { TSMap } from 'typescript-map';
import { Location } from '@angular/common';
import { IAdminAccount, AdminAccount } from '../models/admin-account';


export interface IBaseComponent {

    onLoadUser(err, data);
    onLoadImage(err, data);
    onLoadEventMap(err, data);
    onLoadEvents(err, data);
    onLoadSubscriberInfo(err, data);
    onLoadSubscriberPage(err, data);
    onLoadSubscriberDetails(err, data);
}


@Component({
    selector: 'app-base',
    templateUrl: ''
})
export class BaseComponent implements IBaseComponent {

    constructor(
        public initAppService: InitAppService,
        public apiController: ApiControllerService,
        public userService: UserLoginService,
        public router: Router,
        public route: ActivatedRoute,
        public imageService: ImageService,
        public spinner: Ng4LoadingSpinnerService,
        public _location: Location) { }

    public imageInfoList: IImage[];
    public eventInfoList: IEvent[];
    public userName: string;

    home: ISubscriberPage = {
        companyName: 'Agency Name',
        contactPerson: '',
        id: 1,
        background: '',
        logo: 'assets/img/logo-default.png',
        description: 'Some description on the photography agency. Service offering and studio informations.',
        contactInfo: 'Agency Contact Information will appear here',
        headerBgType: 1,
        headerBgPattern: 2,
        headerBgColor: '',
        bodyBgType: 2,
        bodyBgPattern: 2,
        bodyBgColor: '',
        logoPosition: 1,
        bodyBgImage: ''
    };

    public user: IUser;
    public showHeader = true;
    public subscriberInfo: ISubscriber;
    public subscriberDetails: ISubscriberDetails;
    public errorMessage: string;
    public account: IAgencyAccount = new AgencyAccount();
    public subscriptionType = 0; // 0- no subcription, 1-free subscription, 2- subscription
    public noOfImages: number;
    public noOfEvents: number;
    public freeDuration: string;
    public duration: string;
    public createTime: string;
    public endTime;
    public freeEndTime;
    public noOfSubscribers: number;
    startLoadingData() {
        this.spinner.show();
        console.log('loader onn XXXXXXX>');
        this.initAppService.loadAllData(
            this.getUserName(), 0, this);
    }

    public getUserName() {
        if (isNullOrUndefined(this.userName)) {
            return this.apiController.getUserName();
        }
        return this.userName;
    }

    public onLoadUser(err, data) {

        if (err) {
            console.log('Error on: onLoadUser');
        }
        if (!isNullOrUndefined(UserService.selectedUser)) {
            this.user = UserService.selectedUser;
            this.userName = UserService.selectedUser.name;
            this.account.name = UserService.selectedUser.name;
            this.account.email = UserService.selectedUser.email;
            this.account.phone = UserService.selectedUser.phone;
            console.log('on: onLoadUser');
            this.OnUserSuccess();
        }
    }

    onLoadImage(err, data) {
        this.spinner.hide();
        if (err) {
            console.log('Error on: onLoadImage');
        }
        this.imageInfoList = ImageService.imageList;

        if (!isNullOrUndefined(ImageService.imageList)) {
            this.noOfImages = ImageService.imageList.length;
            console.log('on: onLoadEvents');
        }
        console.log('on: onLoadImage');
        this.OnImageSuccess();
    }

    onLoadEventMap(err, data) {
        this.spinner.hide();
        if (err) {
            console.log('Error on: onLoadEventMap');
        }
        this.eventInfoList = ImageService.eventList;
        if (!isNullOrUndefined(ImageService.eventList)) {
            this.noOfEvents = ImageService.eventList.length;
            console.log('on: onLoadEvents');
        }
        console.log('on: onLoadEventMap');

    }

    onLoadEvents(err, data) {
        this.spinner.hide();
        if (err) {
            console.log('Error on: onLoadUser');
        }
        this.eventInfoList = ImageService.eventList;
        if (!isNullOrUndefined(ImageService.eventList)) {
            this.noOfEvents = ImageService.eventList.length;
            console.log('on: onLoadEvents');
        }

        this.OnEventsSuccess();
    }

    onLoadSubscriberInfo(err, data) {
        this.spinner.hide();
        if (err) {
            console.log('Error on: onLoadUser');
        }

        if (!isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
            this.subscriberInfo = SubscriberService.userSubscriberInfo;
            this.subscriberInfo.createTime = SubscriberService.userSubscriberInfo.createTime;
            this.subscriptionType = SubscriberService.userSubscriberInfo.licenseId;
            this.freeDuration = this.getFreeDuration();
            this.duration = this.getPremiumDuration();
            this.createTime = this.subscriberInfo.createTime;
            const d = new Date(this.createTime);
            const d1 = new Date(this.createTime);
            d.setDate(d.getDate() + 364);
            this.endTime = d;
            d1.setDate(d1.getDate() + 29);
            this.freeEndTime = d1;
            console.log('on: onLoadSubscriberInfo');
            console.log(this.subscriptionType);
        }

        this.OnSubscriberSuccess();

    }

    onLoadSubscriberPage(err, data) {
        this.spinner.hide();
        if (err) {
            console.log('Error on: onLoadUser');
        }
        console.log('on: onLoadSubscriberPage');
        if (!isNullOrUndefined(SubscriberService.userSubscriberInfo) &&
            !isNullOrUndefined(SubscriberService.userSubscriberInfo.subscriberPage)) {
            this.home = SubscriberService.userSubscriberInfo.subscriberPage;
        }
        this.OnSubscribePageSuccess();
    }

    onLoadSubscriberDetails(err, data) {
        this.spinner.hide();
        if (err) {
            console.log('Error on: onLoadSubscriberDetails');
        }
        if (!isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
            this.subscriberDetails =
                SubscriberService.userSubscriberInfo.subscriberDetails;
        }
    }

    OnUserSuccess() {
        // override this method if needed.
    }

    OnImageSuccess() {
        // override this method if needed.
    }

    OnEventsSuccess() {
        // override this method if needed.
    }

    OnSubscriberSuccess() {
        // override this method if needed.
    }

    OnSubscribePageSuccess() {
        // override this method if needed.
    }
    backClicked() {
        this._location.back();
    }
    getPremiumDuration(){
        return this.getPremiumDurationBySubscriber(SubscriberService.userSubscriberInfo);
    }
    getPremiumDurationBySubscriber(subscriberInfo: ISubscriber) {
        if (!isNullOrUndefined(subscriberInfo)) {
            const time = subscriberInfo.createTime;
            const d = new Date(time);
            d.setDate(d.getDate() + 364);
            const endTime = d;
            let today = new Date();
            let deadline = new Date(endTime);
            subscriberInfo.duration = this.daysBetween(today, deadline);
            const valid = subscriberInfo.duration;
            return '' + valid;
        }
    }
    getFreeDuration() {
        if (!isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
            const time = this.subscriberInfo.createTime;
            const d = new Date(time);
            d.setDate(d.getDate() + 29);
            const endTime = d;
            let today = new Date();
            let deadline = new Date(endTime);
            this.subscriberInfo.duration = this.daysBetween(today, deadline);
            const valid = this.subscriberInfo.duration;
            return '' + valid;
        }
    }
    getEndTime(time, type) {
        if (type == 1) {
            console.log('type is >>>', type);
            let t = time.setDate(time.getDate() + 30);
            console.log(t);
            return t;
        }
        else if (type == 2) {
            console.log('type is >>>', type);
            let t = time.setDate(time.getDate() + 365);
            console.log(t);
            return t;
        }
    }
    daysBetween(today: Date, deadline: Date) {
        //Get 1 day in milliseconds
        var one_day = 1000 * 60 * 60 * 24;

        // Convert both dates to milliseconds
        var date1_ms = today.getTime();
        var date2_ms = deadline.getTime();

        // Calculate the difference in milliseconds
        var difference_ms = date2_ms - date1_ms;

        // Convert back to days and return
        return Math.round(difference_ms / one_day);
    }
}

export interface IBaseAdminComponent {

    //  onLoadAllUser(err, data);
    // onLoadLatestUser(err, data);
}

@Component({
    selector: 'app-admin-base',
    templateUrl: ''
})
export class BaseAdminComponent extends BaseComponent implements IBaseAdminComponent {

    public subscribersList: ISubscriber[] = [];
    // public subscribers: ISubscriber;
    public adminAccount: IAdminAccount = new AdminAccount();
    public userAllList: IUser[];
    public userLatestList: IUser[];

    getUserById(userId: number) {

        console.log(AdminService.allUsers);
        const index: number =  AdminService.allUsers.findIndex(element => {
            return element.id === userId    
        });

        if(index >= 0){
            return AdminService.allUsers[index];
        }

        return null;
    }

    startLoadingAdminData() {
        console.log('loading user list');
        this.loadAllUser();
    }

    onLoadAllUser() {
        if (!isNullOrUndefined(AdminService.allUsers)) {
            this.userAllList = AdminService.allUsers;
            this.userLatestList = AdminService.latestUsers;
        }
    }

    loadAllUser() {
        if(isNullOrUndefined(AdminService.allUsers)){
            this.onLoadAllUser();
            return;
        }
        this.initAppService.loadAllUsers((err, data) => {
            if (err) {
                console.log('Error on: onLoadUser');
            }
            if (!isNullOrUndefined(AdminService.allUsers)) {
                var users = AdminService.allUsers.filter(e => e.type < 2);
                console.log('loaded user list');
                
                AdminService.allUsers.forEach(element => {
                    if (isNullOrUndefined(element.subscriberId) || element.subscriberId < 1) {
                    } else {
                        this.initAppService.loadSubscriberBase(element, (err, data) => {
                            element.subscriber = data;
                            this.subscribersList.push(data);
                            this.initAppService.loadSubscriberHomeBase(element, (err1, data1) => {
                                element.subscriber.subscriberPage = data1;
                            });
                        });
                    }
                });

                console.log(AdminService.allUsers);
                AdminService.allUsers = this.userAllList =  AdminService.allUsers.filter(e => e.type < 2 
                    && (!isNullOrUndefined(e.subscriberId) 
                    || e.subscriberId > 0
                    || !isNullOrUndefined(e.subscriber.subscriberPage)));

                console.log(this.userAllList);
                AdminService.latestUsers = this.userLatestList = this.userAllList.slice(this.userAllList.length - 5, this.userAllList.length);
                this.userLatestList.sort((a1: IUser, a2: IUser) => {
                    return a1.createTime > a2.createTime ? 1 : -1});
                console.log(this.userLatestList);
                this.noOfSubscribers = this.userAllList.length;
            }
        });
    }

    loadLatestUser() {
        this.initAppService.loadLatestUsers((err, data) => {
            if (err) {
                console.log('Error on: onLoadUser');
            }
            if (!isNullOrUndefined(AdminService.latestUsers)) {

                this.userLatestList = AdminService.latestUsers.filter(e => e.type < 2);
                console.log('loaded user latest list');
                console.log(this.userLatestList);
                this.noOfSubscribers = this.userLatestList.length;
                this.userLatestList.forEach(element => {
                    if (isNullOrUndefined(element.subscriberId) || element.subscriberId < 1) {
                    } else {
                        this.initAppService.loadSubscriberBase(element, (err, data) => {
                            element.subscriber = data;
                            this.subscribersList.push(data);
                            this.initAppService.loadSubscriberHomeBase(element, (err1, data1) => {
                                element.subscriber.subscriberPage = data1;
                            });
                        });
                        console.log('subscribersList>>>>>>>> :');
                        console.log(this.subscribersList);
                    }
                });
                this.userLatestList = this.userLatestList.filter(e2 => !isNullOrUndefined(e2.subscriber.subscriberPage));
            }
        });
    }
    backClicked() {
        this._location.back();
    }
}


export interface IBaseHomeComponent {

}

@Component({
    selector: 'app-Home-base',
    templateUrl: ''
})
export class BaseHomeComponent extends BaseComponent {

    public setHeaderColor(color, compId: string) {
        this.removeAllHeader();
        document.getElementById(compId).style.background = color;
    }

    public setHeaderPattern(patternId, compId) {
        if (patternId < 1 || patternId > 6) {
            return;
        }
        this.removeAllHeader();
        document.getElementById(compId).style.backgroundImage = 'url(assets/img/patt' + patternId + '.jpg)';
    }

    public setHeaderImage(url: string, compId = 'agencyNav') {
        this.removeAllHeader();
        document.getElementById(compId).style.backgroundImage = 'url(' + url + ')';
    }

    public setBgColor(newColor, compId = 'homePreviewContent') {
        this.removeAllBody();
        console.log('value', newColor);
        document.getElementById(compId).style.background = newColor;
    }

    public setBodyPattern(patternId, compId) {
        if (patternId < 1 || patternId > 6) {
            return;
        }
        this.removeAllBody();
        console.log('i am called');
        document.getElementById(compId).style.backgroundImage = 'url(assets/img/patt' + patternId + '.jpg)';
    }

    public setBodyImage(url: string, compId = 'homePreviewContent') {
        this.removeAllBody();
        document.getElementById(compId).style.backgroundImage = 'url(' + url + ')';
    }

    public removeHeaderPattern(compId = 'agencyNav') {
        document.getElementById(compId).style.backgroundImage = '';
    }

    public removeHeaderImage(compId = 'agencyNav') {
        document.getElementById(compId).style.backgroundImage = '';
    }

    public removeHeaderColor(compId = 'agencyNav') {
        document.getElementById(compId).style.background = '#201f24';
    }

    public removeBodyPattern(compId = 'homePreviewContent') {
        document.getElementById(compId).style.backgroundImage = '';
    }

    public removeBodyImage(compId = 'homePreviewContent') {
        document.getElementById(compId).style.backgroundImage = '';
    }

    public removeBodyColor(compId = 'homePreviewContent') {
        document.getElementById(compId).style.background = '#ffffff';
    }

    public removeAllHeader() {
        this.removeHeaderPattern();
        this.removeHeaderImage();
        this.removeHeaderColor();
    }

    public removeAllBody() {
        this.removeBodyPattern();
        this.removeBodyImage();
        this.removeBodyColor();
    }
}
