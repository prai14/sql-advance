import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../shared/base.component';

@Component({
  selector: 'app-secure-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent extends BaseComponent implements OnInit {

  //constructor() { }

  ngOnInit() {
    this.showHeader = true;
    const loc = window.location;
    this.userName = loc.pathname.substring(1);
    this.userName = this.userName.substring(this.userName.indexOf('/') + 1);
    console.log('>>>>>>>>>>>>>>>>>>',this.userName);
    if(this.userName == 'home'){
      this.showHeader = false;
    }
  
  }

}
