import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { agencyComponent } from './agency.component';

describe('agencyComponent', () => {
  let component: agencyComponent;
  let fixture: ComponentFixture<agencyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ agencyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(agencyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
