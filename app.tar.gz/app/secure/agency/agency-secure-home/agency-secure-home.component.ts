import { BaseHomeComponent } from '../../../shared/base.component';
import { SubscriberService } from '../../../service/sql-db/subscriber.service';
import { isNullOrUndefined } from 'util';
import { AfterViewInit, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { ISubscriberPage, SubscriberPageInfo } from '../../../models/subscriber-page-info';
import { ImageService } from '../../../service/sql-db/image.service';
import { UserService } from '../../../service/sql-db/user.service';
import { UserLoginService } from '../../../service/user-login.service';
import { ApiControllerService } from '../../../service/api-controller.service';
import { Callback, CognitoCallback, LoggedInCallback } from '../../../service/cognito.service';
import { IAgencyAccount, AgencyAccount } from '../../../models/agency-account';

@Component({
  selector: 'agency-secure-home',
  templateUrl: './agency-secure-home.component.html', 
  styleUrls: ['./agency-secure-home.component.css']
})
export class agencySecureHomeComponent extends BaseHomeComponent 
implements CognitoCallback, LoggedInCallback, OnInit, AfterViewInit  {

  selectedLogoFile: FileList;
  selectedBgFile: FileList;
  eventId = 0;
  ImageUrl;
  thumbnail1 = 'assets/img/img3.jpg';
  thumbnail2 = 'assets/img/img7.jpg';
  thumbnail3 = 'assets/img/img5.jpg';
  imageName = 'ImageName.jpg';
  eventName = 'Event Name';
  headColor;
  bodyColor;
  sub: any;
  textColor;
  /* rule: any = {
    'mode' : true,
    'value1' : true,
    'value2' : false
    }; */
  patternId: any[] = [
    {
      'id': '1',
      'divId':'pat1',
      'image':'patt1.jpg'
    },
    {
      'id': '2',
      'divId':'pat2',
      'image':'patt2.jpg'
    },
    {
      'id': '3',
      'divId':'pat3',
      'image':'patt3.jpg'
    },
    {
      'id': '4',
      'divId':'pat4',
      'image':'patt4.jpg'
    },
    {
      'id': '5',
      'divId':'pat5',
      'image':'patt5.jpg'
    },
    {
      'id': '6',
      'divId':'pat6',
      'image':'patt6.jpg'
    }
  ];
  ngOnInit() {
    this.showHeader = false;
    this.userService.isAuthenticated(this);
  }

  ngAfterViewInit() {
    this.viewInit();
    this.loadBg();
  }

  onLogin() {
    this.viewInit();
    this.startLoadingData();
  }

  viewInit() {
    console.log('agency-secure.component' + ' onlogin: start');
    const loc = window.location;
    this.userName = loc.pathname.substring(1, loc.pathname.indexOf('/', 1));
    this.sub = this.route.params.subscribe(params => {
      this.eventId = params['id'];
      console.log('onLogin :: ' + this.userName);
      if (!isNullOrUndefined(SubscriberService.userSubscriberInfo)
        && !isNullOrUndefined(SubscriberService.userSubscriberInfo.subscriberPage)) {
        console.log('agency-secure.component' + ' onlogin: data loaded');
        this.home = SubscriberService.userSubscriberInfo.subscriberPage;
        document.getElementById('agencyNav').style.background = this.home.headerBgColor;
        document.getElementById('homePreviewContent').style.background = this.home.bodyBgColor;
        console.log(SubscriberService.userSubscriberInfo.subscriberPage);
        this.setHeaderPattern(this.home.headerBgPattern);
        this.setBodyPattern(this.home.bodyBgPattern);
        this.setBodyImage(this.home.bodyBgImage);
        this.setHeaderTextColor(this.home.headerTextColor);
        if(this.home.logoPosition == 1){
          this.logoPositionLeft();
        }
        else if(this.home.logoPosition == 2){
          this.logoPositionRight();
        }
      }
    });
  }

  OnSubscribePageSuccess() {
    document.getElementById('agencyNav').style.background = this.home.headerBgColor;
        document.getElementById('homePreviewContent').style.background = this.home.bodyBgColor;
    this.setHeaderPattern(this.home.headerBgPattern);
    this.setBodyPattern(this.home.bodyBgPattern);
    this.setBodyImage(this.home.bodyBgImage);
    this.setHeaderTextColor(this.home.headerTextColor);
    if(this.home.logoPosition == 1){
      this.logoPositionLeft();
    }
    else if(this.home.logoPosition == 2){
      this.logoPositionRight();
    }

    this.loadBg();
  }

  loadBg() {
    this.removeAllBody();
    this.removeAllHeader();

    if (isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
      return;
    }

    if (this.home.headerBgType == 1){
      this.setHeaderColor(this.home.headerBgColor);
    } else if(this.home.headerBgType == 2){
      this.setHeaderPattern(this.home.headerBgPattern);
    } else if(this.home.headerBgType == 3){
      this.setHeaderImage(this.home.background);
    }

    if (this.home.bodyBgType == 1){
      this.setBgColor(this.home.bodyBgColor);
    } else if(this.home.bodyBgType == 2){
      this.setBodyPattern(this.home.bodyBgPattern);
    } else if(this.home.bodyBgType == 3){
      this.setBodyImage(this.home.bodyBgImage);
    }

  }
  cognitoCallback(message: string, result: any) {
    if (message != null) { //error
      this.router.navigate(['/login']);
    } else { //success
      this.onLogin();
    }
  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
    if (isLoggedIn) {
      this.onLogin();
    }
  }

  routeToHome() {
    this.router.navigate(['/' + this.userService.getUserName() + '/home']);
  }

  onSave() {
    this.apiController.saveSubscriberPage(this.home);
    document.getElementById('save').innerHTML = 'Saving...';

  }

  updateLogoFileSelection(input) {
    console.log('updateLogoFileSelection');
    this.selectedLogoFile = input.target.files as FileList;
    this.imageService.uploadAssets(UserService.selectedUser.id,
      this.selectedLogoFile[0], (err, data) => {
        if (err) {
          console.log('Error::', err);
        } else {
          console.log('updateLogoFileSelection :: ' + data.Location);
          this.home.logo = data.Location;
          console.log(this.home);
        }
      });
  }

  updateBodyBgFileSelection(input) {
    console.log('updateBgFileSelection');
    this.selectedBgFile = input.target.files as FileList;
    this.imageService.uploadAssets(UserService.selectedUser.id,
      this.selectedBgFile[0], (err, data) => {
        if (err) {
          console.log('Error::', err);
        } else {
          console.log('updateBgFileSelection :: ' + data.Location);
          this.home.bodyBgImage = data.Location;
          console.log(this.home);
          this.setBodyImage(data.Location);
        }
      });
  }

  updateBgFileSelection(input) {
    console.log('updateBgFileSelection');
    this.selectedBgFile = input.target.files as FileList;
    this.imageService.uploadAssets(UserService.selectedUser.id,
      this.selectedBgFile[0], (err, data) => {
        if (err) {
          console.log('Error::', err);
        } else {
          console.log('updateBgFileSelection :: ' + data.Location);
          this.home.background = data.Location;
          console.log(this.home);
          this.setHeaderImage(data.Location);
        }
      });
  }
  setHeaderTextColor(color){
    document.getElementById('companyTitle').style.color = color;
    document.getElementById('companyDesc').style.color = color;
    this.home.headerTextColor = color;
    this.textColor = color;
  }
  setHeaderColor(color) {
    console.log('setHeaderColor Rajiv-' + this.home.headerBgType);
    this.removeAllHeader();
    document.getElementById('agencyNav').style.background = color;
    this.home.headerBgColor = color;
    this.headColor = color;
    this.home.headerBgType = 1;
  }
  setHeaderPattern(patternId, compId = 'agencyNav'){
    console.log('setHeaderPattern Rajiv- ' + this.home.headerBgType);
    if(patternId < 1 || patternId > 6){
      return;
    }
    this.removeAllHeader();
    document.getElementById(compId).style.backgroundImage = 'url(assets/img/patt'+ patternId +'.jpg)';
    this.home.headerBgPattern = patternId;
    this.home.headerBgType = 2;
  }
  setHeaderImage(url: string, compId = 'agencyNav'){
    this.removeAllHeader();
    console.log('setHeaderImage Rajiv-' + this.home.headerBgType);
      document.getElementById(compId).style.backgroundImage = 'url(' + url + ')';
      this.home.background = url;
      this.home.headerBgType = 3;
    }
    
  setBgColor(newColor, compId = 'homePreviewContent') {
    this.removeAllBody();
    console.log('value', newColor);
    console.log('setBodyColor Rajiv-' + this.home.bodyBgType);
    document.getElementById(compId).style.background = newColor;
    this.home.bodyBgColor = newColor;
    this.bodyColor = newColor;
    this.home.bodyBgType = 1;
  }
  setBodyPattern(patternId, compId = 'homePreviewContent') {
  
    console.log('setBodyPattern');
    console.log(patternId);
    if (patternId < 1  || patternId > 6) {
      return;
    }
    this.removeAllBody();
    console.log('i am called');
    console.log('setBodyPattern Rajiv-' + this.home.bodyBgType);
    document.getElementById('homePreviewContent').style.backgroundImage = 'url(assets/img/patt'+ patternId +'.jpg)';
    this.home.bodyBgPattern = patternId;
    this.home.bodyBgType = 2;

  }
  setBodyImage(url: string, compId = 'homePreviewContent') {
    console.log('url');
    this.removeAllBody();
    console.log('setBodyImage Rajiv-' + this.home.bodyBgType);
    document.getElementById(compId).style.backgroundImage = 'url(' + url + ')';
    this.home.bodyBgImage = url;
    this.home.bodyBgType = 3;
  }
  
  removeHeaderPattern(compId = 'agencyNav') {
    document.getElementById(compId).style.backgroundImage = '';
    this.home.headerBgPattern = -1;
  }


  removeHeaderImage(compId = 'agencyNav') {
    document.getElementById(compId).style.backgroundImage = '';
    //this.home.background = "";
  }

  removeHeaderColor(compId = 'agencyNav') {
    document.getElementById(compId).style.background = '#201f24';
  }
  removeBodyPattern(compId = 'homePreviewContent') {
    document.getElementById(compId).style.backgroundImage = '';
    this.home.bodyBgPattern = -1;
  }

  removeBodyImage(compId = 'homePreviewContent') {
    document.getElementById(compId).style.backgroundImage = '';
    //this.home.bodyBgImage = "";
  }

  removeBodyColor(compId = 'homePreviewContent') {
    document.getElementById(compId).style.background = '#ffffff';
  }

  removeAllHeader() {
    this.removeHeaderPattern();
    this.removeHeaderImage();
    this.removeHeaderColor();
  }

  removeAllBody() {
    this.removeBodyPattern();
    this.removeBodyImage();
    this.removeBodyColor();
  }

  logoPositionLeft(){
    document.getElementById('logoContent').style.cssFloat = 'left';
    document.getElementById('descContent').style.cssFloat = 'right';
    this.home.logoPosition = 1;
   // document.getElementById('leftRadio').setAttribute('value','true');
   // document.getElementById('rightRadio').setAttribute('value','false');
   //val.checked = true;
  
  }
  logoPositionRight(){
    document.getElementById('logoContent').style.cssFloat = 'right';
    document.getElementById('descContent').style.cssFloat = 'left';
    this.home.logoPosition = 2;
   // document.getElementById('rightRadio').setAttribute('value','true');
   // document.getElementById('leftRadio').setAttribute('value','false');
    //document.getElementById('rightRadio').setAttribute('value','false');
    
  }
  /* setRadioLeft(){
    document.getElementById('leftRadio').setAttribute('value','true');
  }
  setRadioRight(){
    document.getElementById('rightRadio').setAttribute('value','true')
  } */
}
