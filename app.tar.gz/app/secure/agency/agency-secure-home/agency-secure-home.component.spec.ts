import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { agencySecureHomeComponent } from './agency-secure-home.component';

describe('agencySecureHomeComponent', () => {
  let component: agencySecureHomeComponent;
  let fixture: ComponentFixture<agencySecureHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ agencySecureHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(agencySecureHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
