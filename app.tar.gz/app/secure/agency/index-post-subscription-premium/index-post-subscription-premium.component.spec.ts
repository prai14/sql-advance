import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexPostSubscriptionPremiumComponent } from './index-post-subscription-premium.component';

describe('IndexPostSubscriptionPremiumComponent', () => {
  let component: IndexPostSubscriptionPremiumComponent;
  let fixture: ComponentFixture<IndexPostSubscriptionPremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndexPostSubscriptionPremiumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexPostSubscriptionPremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
