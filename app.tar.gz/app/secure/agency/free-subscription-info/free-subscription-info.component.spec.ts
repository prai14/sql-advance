import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FreeSubscriptionInfoComponent } from './free-subscription-info.component';

describe('FreeSubscriptionInfoComponent', () => {
  let component: FreeSubscriptionInfoComponent;
  let fixture: ComponentFixture<FreeSubscriptionInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FreeSubscriptionInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FreeSubscriptionInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
