import { Component, OnInit } from '@angular/core';
import { ISubscriberPage, SubscriberPageInfo } from '../../../models/subscriber-page-info';
import { Router } from '@angular/router';
import { ApiControllerService } from '../../../service/api-controller.service';
import { UserLoginService } from '../../../service/user-login.service';
import { ChallengeParameters, CognitoCallback, LoggedInCallback } from '../../../service/cognito.service';
import { BaseComponent, IBaseComponent } from '../../../shared/base.component';
import { isNullOrUndefined } from 'util';
import { UserService } from '../../../service/sql-db/user.service';
import { ISubscriber } from '../../../models/subscriber';
@Component({
  selector: 'free-subscription-info',
  templateUrl: './free-subscription-info.component.html',
  styleUrls: ['./free-subscription-info.component.css']
})
export class FreeSubscriptionInfoComponent extends BaseComponent
  implements OnInit, IBaseComponent, CognitoCallback, LoggedInCallback {
  subsInfo: ISubscriber;
  public createTime: string;
  validity = '30';
  public endTime: string;
  noOfLicense = 1;
  noOfDevice = 2;
  d;
  valid;
  ngOnInit() {
    this.userService.isAuthenticated(this);
    console.log(this.subscriberInfo.createTime);
  //  if (!isNullOrUndefined(this.subscriberInfo)) {
      this.createTime = this.subscriberInfo.createTime;
      this.d = new Date(this.createTime);
      // console.log('d>>>>'+ this.d);
      this.d.setDate(this.d.getDate() + 30);
      this.endTime = this.d;
      let today = new Date();
      let deadline = new Date(this.endTime);
      this.subscriberInfo.duration = this.daysBetween(today, deadline);
      this.valid = this.subscriberInfo.duration;
      //console.log("The daysBetween function >>>"+this.daysBetween(today,deadline));
   // }
  }
  daysBetween(today: Date, deadline: Date) {
    //Get 1 day in milliseconds
    var one_day = 1000 * 60 * 60 * 24;

    // Convert both dates to milliseconds
    var date1_ms = today.getTime();
    var date2_ms = deadline.getTime();

    // Calculate the difference in milliseconds
    var difference_ms = date2_ms - date1_ms;

    // Convert back to days and return
    return Math.round(difference_ms / one_day);
  }
  onLogin() {
    this.startLoadingData(); 
    //console.log('>>>>>' + this.subscriberInfo.createTime);
    this.createTime = this.subscriberInfo.createTime;
    this.d = new Date(this.createTime);
   // console.log('d>>>>'+ this.d);
    this.d.setDate(this.d.getDate() + 30);
    this.endTime = this.d;
    let today = new Date();
    let deadline = new Date(this.endTime);
    this.subscriberInfo.duration = this.daysBetween(today,deadline);
    this.valid = this.subscriberInfo.duration;
  }

  cognitoCallback(message: string, result: any) {
    if (message != null) { //error
      this.router.navigate(['/login']);
    } else { //success
      this.onLogin();
    }
  }
  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {

  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
    if (isLoggedIn) {
      this.onLogin();
    }
  }

  cancelMFA(): boolean {
    return false;   //necessary to prevent href navigation
  }

  routeTo() {
    this.router.navigate(['/' + this.apiController.getUserName() + '/subscription-plans'])
  }
}
