import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnsuscribDashboardComponent } from './unsuscrib-dashboard.component';

describe('UnsuscribDashboardComponent', () => {
  let component: UnsuscribDashboardComponent;
  let fixture: ComponentFixture<UnsuscribDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnsuscribDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnsuscribDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
