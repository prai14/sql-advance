import { isNullOrUndefined } from 'util';
import { InitAppService } from '../../../service/init-app.service';
import { BaseComponent, IBaseComponent } from '../../../shared/base.component';
import { ISubscriber } from '../../../models/subscriber';
import { IImage } from '../../../models/image-info';
import { TSMap } from 'typescript-map';

import { IEvent } from '../../../models/event';
import { SubscriberService } from '../../../service/sql-db/subscriber.service';
import { UserService } from '../../../service/sql-db/user.service';
import { Component, OnInit } from '@angular/core';
import { AgencyAccount, IAgencyAccount } from '../../../models/agency-account';
import { ISubscriberPage, SubscriberPageInfo, SubscriberPage } from '../../../models/subscriber-page-info';
import { ApiControllerService } from '../../../service/api-controller.service';
import { Router } from '@angular/router';
import { Callback, ChallengeParameters, CognitoCallback, LoggedInCallback } from '../../../service/cognito.service';

import { UserLoginService } from '../../../service/user-login.service';
import { ImageService } from '../../../service/sql-db/image.service';

    @Component({
    selector: 'app-unsuscrib-dashboard',
    templateUrl: './unsuscrib-dashboard.component.html',
    styleUrls: ['./unsuscrib-dashboard.component.css']
    })
    export class UnsuscribDashboardComponent extends BaseComponent

    implements IBaseComponent, CognitoCallback, LoggedInCallback, OnInit{    
        durationPeriod;
        companyName: string = 'Agency Name';
        description: string = 'The dedicated home page is avilable for all users once they subscribe.';
        description2:string = 'The caption about the agency will appear over here.';
    
        ngOnInit() {
    //    this.spinner.show();
      this.userService.isAuthenticated(this);
      
    }

    onlogin() {
        console.log('unsubscribe.component' + ' onlogin: start');
        if (UserService.selectedUser != null) {
            
            if (!isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
                this.subscriptionType = SubscriberService.userSubscriberInfo.licenseId;
                console.log('this.subscriptionType :: ' + this.subscriptionType);
            }
            
            this.account.name = UserService.selectedUser.name;
            this.account.email = UserService.selectedUser.email;
            this.account.phone = UserService.selectedUser.phone;
            this.home.companyName = "Agency Name";
            this.home.description = "Description appears here";
            if (!isNullOrUndefined(SubscriberService.userSubscriberInfo)){
             
            }
        }
        
        this.startLoadingData();
    }

    cognitoCallback(message: string, result: any) {
        if (message != null) { //error
                this.router.navigate(['/login']);
        } else { //success
            console.log('unsubscribe.component' + ' cognitoCallback: success');
        this.onlogin();
        }
    }

    handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {
    }

    isLoggedIn(message: string, isLoggedIn: boolean) {
        if (isLoggedIn) {
            console.log('unsubscribe.component' + ' isLoggedIn: success');
            this.onlogin();
        }
    }

    cancelMFA(): boolean {
        return false;
    }

    routeToAccount() {
        this.router.navigate(['/' + this.apiController.getUserName() + '/agency-account']);
    }

    routeToHomeConfig() {
        this.router.navigate(['/' + this.apiController.getUserName() + '/homecontrols']);
    }

    routeTO(type: string) {
        console.log('routing to respective page');
        if (this.subscriptionType == 0){
            this.router.navigate(['/' + this.apiController.getUserName() + '/subscription-plans']);
        } else if(this.subscriptionType > 0) {
            if (type === 'my-upload') {
                this.router.navigate(['/' + this.apiController.getUserName() + '/photos']);
                return;
            }
            else if (type === 'subscription-info') {
            if( this.subscriptionType == 1) {
                this.router.navigate(['/' + this.apiController.getUserName() + '/free-subscription-info']);
                return;
            }
            else if(this.subscriptionType > 1) {
                this.router.navigate(['/' + this.apiController.getUserName() + '/premium-subscription-info']);
                return;
            }
        } else if(type === 'home-config') {
                this.router.navigate(['/' + this.apiController.getUserName() + '/homecontrols']);
                return;
            }
        }
    }
}
