import { Success } from 'aws-sdk/clients/elastictranscoder';
import { BaseComponent, IBaseComponent } from '../../../shared/base.component';
import { Component, OnInit } from '@angular/core';
import { street1 } from 'aws-sdk/clients/importexport';
import { ISubscriberPage, SubscriberPageInfo, SubscriberPage } from '../../../models/subscriber-page-info';
import { AgencyAccount, IAgencyAccount } from '../../../models/agency-account';
import { UserService } from '../../../service/sql-db/user.service';
import { ApiControllerService } from '../../../service/api-controller.service';
import { UserLoginService } from '../../../service/user-login.service';
import { Router } from '@angular/router';
import { ChallengeParameters } from '../../../service/cognito.service';
import {Location} from '@angular/common';

@Component({
  selector: 'app-agency-account',
  templateUrl: './agency-account.component.html',
  styleUrls: ['./agency-account.component.css']
})
export class AgencyAccountComponent extends BaseComponent implements IBaseComponent, OnInit {
 

  ngOnInit() {
    if (UserService.selectedUser != null) {
    this.account.name = UserService.selectedUser.name;
    this.account.email = UserService.selectedUser.email;
    this.account.phone = UserService.selectedUser.phone;
    }
     this.userService.isAuthenticated(this);
  }

  onLogin() {
    this.startLoadingData();
  }

  cognitoCallback(message: string, result: any) {
      if (message != null) { //error
        this.router.navigate(['/login']);
      } else { //success
        this.onLogin();
        }
  }
  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {

  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
      if (isLoggedIn) {
          this.onLogin();  
      }
  }

  cancelMFA(): boolean {
      return false;   //necessary to prevent href navigation
  }

    saveData() {
        this.apiController.saveSubscriberPage(this.home);  
    }

  getByUname(uname: string){
    this.apiController.getByUname(uname).subscribe(data => {
        console.log('getByUname:>>'+JSON.stringify(data));
        UserService.selectedUser = data[0];
        this.ngOnInit();
    });
}

}

