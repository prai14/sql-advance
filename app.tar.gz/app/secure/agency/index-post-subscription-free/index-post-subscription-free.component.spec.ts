import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexPostSubscriptionFreeComponent } from './index-post-subscription-free.component';

describe('IndexPostSubscriptionFreeComponent', () => {
  let component: IndexPostSubscriptionFreeComponent;
  let fixture: ComponentFixture<IndexPostSubscriptionFreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndexPostSubscriptionFreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexPostSubscriptionFreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
