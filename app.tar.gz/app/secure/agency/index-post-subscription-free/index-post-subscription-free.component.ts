import { Component, OnInit } from '@angular/core';
import { AgencyAccount, IAgencyAccount } from '../../../models/agency-account';
import { SubscriberPageInfo, ISubscriberPage, SubscriberPage } from '../../../models/subscriber-page-info';
import { UserService } from '../../../service/sql-db/user.service';
import { SubscriberService } from '../../../service/sql-db/subscriber.service';
import { ApiControllerService } from '../../../service/api-controller.service';
import { Router } from '@angular/router';
import { UserLoginService } from '../../../service/user-login.service';
import { ChallengeParameters } from '../../../service/cognito.service';

@Component({
  selector: 'index-post-subscription-free',
  templateUrl: './index-post-subscription-free.component.html',
  styleUrls: ['./index-post-subscription-free.component.css']
})
export class IndexPostSubscriptionFreeComponent implements OnInit {
  account: IAgencyAccount = new AgencyAccount();
  //home: ISubscriberPageInfo = new SubscriberPageInfo();
  home: ISubscriberPage = new SubscriberPage;
  constructor(public apiController: ApiControllerService,
     public subscriberService: SubscriberService,
     public router:Router,
  public userService: UserLoginService) { }
  ngOnInit() {
    if(UserService.selectedUser != null) {
    this.account.name = UserService.selectedUser.name;
    this.account.email = UserService.selectedUser.email;
    this.account.phone = UserService.selectedUser.phone;
    this.home.companyName = " ";    
    this.home.details = " ";
    }
    else {
      this.getByUname(this.apiController.getUserName());
     }
     this.userService.isAuthenticated(this);
  }

  onLogin() {
     
  }

  cognitoCallback(message: string, result: any) {
      if (message != null) { //error
        this.router.navigate(['/login']);
      } else { //success
     
        } 
  }
  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {

  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
        if (isLoggedIn) {
            this.router.navigate(['/'  + this.apiController.getUserName() +
            '/dashboard']);
        }
  }

  cancelMFA(): boolean {
      return false;   //necessary to prevent href navigation
  }
  getByUname(uname:string){
    this.apiController.getByUname(uname).subscribe(data =>{
        console.log('getByUname:>>'+JSON.stringify(data));
        UserService.selectedUser = data[0];
        this.ngOnInit();
    })
}
routeToAccount(){
  this.router.navigate(['/' + this.apiController.getUserName() + '/agency-account']);
}
routeTO(type: string) {
  console.log('routing to respective page');
  if (UserService.selectedUser.subscriberId > 0 &&
      SubscriberService.userSubscriberInfo != null && 
  SubscriberService.userSubscriberInfo.licenseId > 0){
      if (type === 'my-upload') {
          this.router.navigate(['/' + this.apiController.getUserName() + '/photos']);
          return;
      }
  }
  this.router.navigate(['/' + this.apiController.getUserName() + '/subscription-plans']);
}
routeToSubscriptionInfo(type:string){
      if (type === 'free-subscription-info'){
        this.router.navigate(['/' + this.apiController.getUserName() + '/free-subscription-info']);
        return;
      }
}
}
