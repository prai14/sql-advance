import { Router } from '@angular/router';
import { ApiControllerService } from '../../../service/api-controller.service';
import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../service/sql-db/user.service';
import { UserLoginService } from '../../../service/user-login.service';
import { ChallengeParameters } from '../../../service/cognito.service';

@Component({
  selector: 'app-subscribe-plan',
  templateUrl: './subscribe-plan.component.html',
  styleUrls: ['./subscribe-plan.component.css']
})
export class SubscribePlanComponent implements OnInit {
 
  constructor(public router: Router,
    public usersService: UserService,
    public apiController: ApiControllerService,
  public userService: UserLoginService) { }

  ngOnInit() {
    this.userService.isAuthenticated(this);
  }

  onLogin() {
     
  }

  cognitoCallback(message: string, result: any) {
      if (message != null) { //error
        this.router.navigate(['/login']);
      } else { //success
    
  }
  }
  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {

  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
      if (isLoggedIn) {
      }
  }

  cancelMFA(): boolean {
      return false;   //necessary to prevent href navigation
  }

  tryNow() {
    const self = this;

    this.apiController.saveSubscriber(1, (err, data) => {
      if (err) {
        console.log('you are not able to subscribe');
      } else {
        self.router.navigate([
          '/' + this.apiController.getUserName() + '/dashboard'
        ]);
      }
    });
  }

  buyNow() {
    const self = this;
    this.apiController.saveSubscriber(2, (err, data) => {
      if (err) {
        console.log('you are not able to subscribe');
      } else {
        self.router.navigate([
          '/' + this.apiController.getUserName() + '/dashboard'
        ]);
      }
    });
  }
}
