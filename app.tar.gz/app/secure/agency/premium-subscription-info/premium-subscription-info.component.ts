import { Component, OnInit } from '@angular/core';
import { ISubscriberPage, SubscriberPageInfo } from '../../../models/subscriber-page-info';
import { Router } from '@angular/router';
import { UserLoginService } from '../../../service/user-login.service';
import { ApiControllerService } from '../../../service/api-controller.service';
import { ChallengeParameters, CognitoCallback, LoggedInCallback } from '../../../service/cognito.service';
import { ISubscriber } from '../../../models/subscriber';
import { BaseComponent, IBaseComponent } from '../../../shared/base.component';
import { SubscriberService } from '../../../service/sql-db/subscriber.service';

@Component({
  selector: 'premium-subscription-info',
  templateUrl: './premium-subscription-info.component.html',
  styleUrls: ['./premium-subscription-info.component.css']
})
export class PremiumSubscriptionInfoComponent extends BaseComponent
 implements OnInit, IBaseComponent, CognitoCallback, LoggedInCallback{
  subsInfo: ISubscriber;
  public createTime: string;
  validity = '1';
  public endTime : string;
  noOfLicense = 1;
  noOfDevice = 2;
  d;
  valid;
  duration;
//  constructor(public apiController:ApiControllerService,public userService: UserLoginService,public router: Router) { }

  ngOnInit() {
    this.userService.isAuthenticated(this);
  }


  
  onLogin() {
    this.startLoadingData();
  }

  cognitoCallback(message: string, result: any) {
      if (message != null) { //error
        this.router.navigate(['/login']);
      } else { //success
        this.onLogin();
  }
  }
  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {

  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
      if (isLoggedIn) {
        this.onLogin();
    }
  }

  cancelMFA(): boolean {
      return false;   //necessary to prevent href navigation
  }

}

