import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumSubscriptionInfoComponent } from './premium-subscription-info.component';

describe('PremiumSubscriptionInfoComponent', () => {
  let component: PremiumSubscriptionInfoComponent;
  let fixture: ComponentFixture<PremiumSubscriptionInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PremiumSubscriptionInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PremiumSubscriptionInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
