import { Component, OnInit } from '@angular/core';
import { ChallengeParameters } from '../../../service/cognito.service';
import { ApiControllerService } from '../../../service/api-controller.service';
import { UserLoginService } from '../../../service/user-login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.css']
})
export class SubscribeComponent implements OnInit {

  constructor(public apiController:ApiControllerService,public userService: UserLoginService,public router: Router) { }

  ngOnInit() {
    this.userService.isAuthenticated(this);
  }

  onLogin() {
     
  }

  cognitoCallback(message: string, result: any) {
      if (message != null) { //error
        this.router.navigate(['/login']);
      } else { //success
      
  }
  }
  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {

  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
      if (isLoggedIn) {
          const myThis = this;
          myThis.router.navigate(['/'  + this.apiController.getUserName() +
          '/dashboard']);
        }
  }

  cancelMFA(): boolean {
      return false;   //necessary to prevent href navigation
  }
}
