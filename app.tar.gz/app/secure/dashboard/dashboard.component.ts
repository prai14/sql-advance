import { BaseComponent, IBaseComponent } from '../../shared/base.component';
import { Component, OnInit } from '@angular/core';
import { ApiControllerService } from '../../service/api-controller.service';
import { Router } from '@angular/router';
import { ChallengeParameters } from '../../service/cognito.service';
import { UserService } from '../../service/sql-db/user.service';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent extends BaseComponent implements IBaseComponent, OnInit {
 
  isAdmin: boolean = false; 
  isAgency: boolean = false;
  
  ngOnInit() {
      this.userService.isAuthenticated(this);  
  }

  onLogin() {
    this.initAppService.loadUser(this.getUserName(), (err, data) => {
        this.user  = UserService.selectedUser;
        console.log(this.user);
        if (this.user.type > 1) {
          this.isAdmin = true;
          this.isAgency = false;
        } else {
          this.isAdmin = false;
          this.isAgency = true;
        }
    });
  }

  OnUserSuccess() {
    if (this.user.type > 1) {
      this.isAdmin = true;
      this.isAgency = false;
    } else {
      this.isAdmin = false;
      this.isAgency = true;
    }
  }

  cognitoCallback(message: string, result: any) {
      if (message != null) { //error
        this.router.navigate(['/login']);
      } else { //success
        this.onLogin();
      }
  }
  handleMFAStep(challengeName: string, challengeParameters: ChallengeParameters, callback: (confirmationCode: string) => any): void {

  }

  isLoggedIn(message: string, isLoggedIn: boolean) {
      if (isLoggedIn) {
        this.onLogin();
      }
  }

  cancelMFA(): boolean {
      return false;   //necessary to prevent href navigation
  }

}
