import { Component, OnInit } from '@angular/core';
import {ImageInfo} from '../../../models/image-info';
import { ImageService } from '../../../service/sql-db/image.service';
import { ApiControllerService } from '../../../service/api-controller.service';
@Component({
  selector: 'app-admin-event-images',
  templateUrl: './admin-event-images.component.html',
  styleUrls: ['./admin-event-images.component.css']
})
export class AdminEventImagesComponent implements OnInit {
  imageInfoList= [];
  imageInfo1: ImageInfo = new ImageInfo();
  imageInfo2: ImageInfo = new ImageInfo();
  imageInfo3: ImageInfo = new ImageInfo();
  imageInfo4: ImageInfo = new ImageInfo();
  imageInfo5: ImageInfo = new ImageInfo();
  imageInfo6: ImageInfo = new ImageInfo();
  imageInfo7: ImageInfo = new ImageInfo();
  imageInfo8: ImageInfo = new ImageInfo();
  imageInfo9: ImageInfo = new ImageInfo();
  imageInfo10: ImageInfo = new ImageInfo();
  constructor(public apiController:ApiControllerService) { }

  ngOnInit() {
   // this.apiController.getEvent();  }
  }
}
