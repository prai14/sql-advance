import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEventImagesComponent } from './admin-event-images.component';

describe('AdminEventImagesComponent', () => {
  let component: AdminEventImagesComponent;
  let fixture: ComponentFixture<AdminEventImagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminEventImagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminEventImagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
