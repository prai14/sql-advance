import { BaseAdminComponent } from '../../../shared/base.component';
import { Component, OnInit } from '@angular/core';
import {SubscriberPageInfo, ISubscriberPage, SubscriberPage} from '../../../models/subscriber-page-info';
import { ISubscriber, Subscriber } from '../../../models/subscriber';

@Component({
  selector: 'app-admin-subscriber-list-uploads',
  templateUrl: './admin-subscriber-list-uploads.component.html',
  styleUrls: ['./admin-subscriber-list-uploads.component.css']
})
export class AdminSubscriberListUploadsComponent extends 
BaseAdminComponent implements OnInit {

  //subscribersList=[];
  //subscribers: ISubscriber = new Subscriber();
 // subscriber: ISubscriberPage = new SubscriberPage();
    
  ngOnInit() {
    this.startLoadingAdminData();
  }
adminSubscriberUploads(userId){
  this.router.navigate(['/admin/subscribers-uploads/' + userId]);
}
}
