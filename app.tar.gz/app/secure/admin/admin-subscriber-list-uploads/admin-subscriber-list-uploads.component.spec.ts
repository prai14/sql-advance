import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSubscriberListUploadsComponent } from './admin-subscriber-list-uploads.component';

describe('AdminSubscriberListUploadsComponent', () => {
  let component: AdminSubscriberListUploadsComponent;
  let fixture: ComponentFixture<AdminSubscriberListUploadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminSubscriberListUploadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSubscriberListUploadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
