import { BaseAdminComponent, IBaseAdminComponent } from '../../shared/base.component';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent extends BaseAdminComponent implements OnInit {

  ngOnInit() {
  }

}
