import { BaseAdminComponent, BaseComponent } from '../../../shared/base.component';
import { IAdminAccount } from '../../../models/admin-account';
import { SubscriberService } from '../../../service/sql-db/subscriber.service';
import { Component, OnInit } from '@angular/core';
import { ISubscriber, Subscriber } from '../../../models/subscriber';
import { ISubscriberPage, SubscriberPageInfo } from '../../../models/subscriber-page-info';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent extends BaseAdminComponent implements OnInit {

  ngOnInit() {
   // this.startLoadingData();
    this.startLoadingAdminData();
    this.adminAccount.name="Paul Conrath";
    this.adminAccount.email="info@phototainment.com";
    this.adminAccount.phone= 2065358383;
    console.log('user >>>> id ');
    console.log()
  }
  insideAgencyDetail(userId){
 this.router.navigate(['/admin/subscribers/'+ userId]);
  }
}
