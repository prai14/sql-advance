import { BaseAdminComponent } from '../../../shared/base.component';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {ImageInfo} from '../../../models/image-info';
import { ImageService } from '../../../service/sql-db/image.service';
import { ApiControllerService } from '../../../service/api-controller.service';

@Component({
  selector: 'app-admin-subscriber-uploads',
  templateUrl: './admin-subscriber-uploads.component.html',
  styleUrls: ['./admin-subscriber-uploads.component.css']
})
export class AdminSubscriberUploadsComponent extends BaseAdminComponent implements OnInit {
  eventId: Observable<string>;
  token: Observable<string>;
  // imageInfoList= [];
  // eventInfoList=[];
  
  ngOnInit() {
    this.startLoadingAdminData();
  }
}