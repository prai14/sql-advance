import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminSubscriberUploadsComponent } from './admin-subscriber-uploads.component';

describe('AdminSubscriberUploadsComponent', () => {
  let component: AdminSubscriberUploadsComponent;
  let fixture: ComponentFixture<AdminSubscriberUploadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminSubscriberUploadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminSubscriberUploadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
