import { Component, OnInit } from '@angular/core';
import { AdminAccount, IAdminAccount } from '../../../models/admin-account';
import { BaseComponent, BaseAdminComponent } from '../../../shared/base.component';
@Component({
  selector: 'app-admin-account',
  templateUrl: './admin-account.component.html',
  styleUrls: ['./admin-account.component.css']
})
export class AdminAccountComponent extends BaseAdminComponent implements OnInit  {

 // constructor() { }
 // account: IAdminAccount = new AdminAccount();
  ngOnInit() {
    this.adminAccount.name="Paul Conrath";
    this.adminAccount.email="info@phototainment.com";
    this.adminAccount.phone= 2065358383;
    this.adminAccount.cAddress="Phototainment 309 S. Cloverdale St. #C9 Seattle, WA 98108";
    this.adminAccount.bAddress="Seattle";
  }

}
