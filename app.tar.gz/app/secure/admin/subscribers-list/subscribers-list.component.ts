import { BaseAdminComponent } from '../../../shared/base.component';
import { Component, OnInit } from '@angular/core';
import {SubscriberPageInfo} from '../../../models/subscriber-page-info';
import { ISubscriber, Subscriber } from '../../../models/subscriber';

@Component({
  selector: 'app-subscribers-list',
  templateUrl: './subscribers-list.component.html',
  styleUrls: ['./subscribers-list.component.css']
})
export class SubscribersListComponent extends BaseAdminComponent implements OnInit {

  //subscribersList: ISubscriber[];
   subscribers: ISubscriber;

  ngOnInit() {
    this.startLoadingAdminData();
  }
  insideAgencyDetail(userId){
    this.router.navigate(['/admin/subscribers/'+ userId]);
     }
}
