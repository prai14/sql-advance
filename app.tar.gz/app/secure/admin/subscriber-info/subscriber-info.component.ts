import { BaseAdminComponent } from '../../../shared/base.component';
import { UserService } from '../../../service/sql-db/user.service';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';
import { ISubscriberPage, SubscriberPageInfo } from '../../../models/subscriber-page-info';
import { Subscriber } from '../../../models/subscriber';
import { User, IUser } from '../../../models/user';
import { UserDetails } from '../../../models/user-details';
import { isNullOrUndefined } from 'util';
//import {Subscriber} from '../../../models/subscriber';
@Component({
  selector: 'app-subscriber-info',
  templateUrl: './subscriber-info.component.html',
  styleUrls: ['./subscriber-info.component.css']
})
export class SubscriberInfoComponent extends BaseAdminComponent implements OnInit {

  subscriberId: Observable<string>;
  token: Observable<string>;
  name;
  userId: number;
  private sub;
  public userData: IUser;
  public comAddress;
  public bussAddress;
  public createTime;
  public endTime;
  public valid;
  /* 
  userName: User;
  home: ISubscriberPage;
  subscriberInfo:SubscriberPageInfo = new SubscriberPageInfo();
  subscriber: Subscriber = new Subscriber();
  constructor( private route: ActivatedRoute ) {
   } */

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.userId = params['id'];
    });
    const loc = window.location;
    if (isNullOrUndefined(this.userId)) {
      this.userId = +loc.pathname.substring(loc.pathname.lastIndexOf('/'));
      console.log(this.userId);
    }
    this.user = this.getUserById(this.userId);
   
    console.log('User data by id >>>');
    console.log(this.user.subscriber);
   
    if(!isNullOrUndefined(this.user.subscriber.subscriberPage)){
      console.log(this.user.subscriber.subscriberPage);
    console.log(this.user.subscriber.subscriberPage.cAddress);
    this.comAddress = this.user.subscriber.subscriberPage.cAddress;
    this.bussAddress = this.user.subscriber.subscriberPage.bAddress;
    }
    this.valid = this.getPremiumDurationBySubscriber(this.user.subscriber);
     this.createTime = this.user.subscriber.createTime;
    const d = new Date(this.createTime);
    d.setDate(d.getDate() + 364);
    this.endTime = d;
  }
}
