import { SubscribePlanComponent } from './secure/agency/subscribe-plan/subscribe-plan.component';
import { SubscribeComponent } from './secure/agency/subscribe/subscribe.component';
import { AgencyAccountComponent } from './secure/agency/agency-account/agency-account.component';
/* import { agencyHomeComponent } from './public/agency-home/agency-home.component'; */
import { agencyComponent } from './secure/agency/agency.component';
import { EventListComponent } from './public/events/eventlist/eventlist.component';
import { EventInfoComponent } from './public/events/eventinfo/eventinfo.component';
import { UnsuscribDashboardComponent } from './secure/agency/unsuscrib-dashboard/unsuscrib-dashboard.component';
import { UploadComponent } from './public/photos/upload/upload.component';
import { MyphotoComponent } from './public/photos/myphoto/myphoto.component';
import {RouterModule, Routes} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import {AboutComponent, HomeComponent, HomeLandingComponent} from './public/home.component';
import {SecureHomeComponent} from './secure/landing/securehome.component';
import {JwtComponent} from './secure/jwttokens/jwt.component';
import {LoginComponent} from './public/auth/login/login.component';
import {RegisterComponent} from './public/auth/register/registration.component';
import {ForgotPassword2Component, ForgotPasswordStep1Component} from './public/auth/forgot/forgotPassword.component';
import {LogoutComponent, RegistrationConfirmationComponent} from './public/auth/confirm/confirmRegistration.component';
import {ResendCodeComponent} from './public/auth/resend/resendCode.component';
import {NewPasswordComponent} from './public/auth/newpassword/newpassword.component';
import { IndexPostSubscriptionFreeComponent } from './secure/agency/index-post-subscription-free/index-post-subscription-free.component';
import { IndexPostSubscriptionPremiumComponent } from './secure/agency/index-post-subscription-premium/index-post-subscription-premium.component';
import { FreeSubscriptionInfoComponent } from './secure/agency/free-subscription-info/free-subscription-info.component';
import { PremiumSubscriptionInfoComponent } from './secure/agency/premium-subscription-info/premium-subscription-info.component';
import { AdminComponent } from './secure/admin/admin.component';
import { AdminDashboardComponent } from './secure/admin/admin-dashboard/admin-dashboard.component';
import { DashboardComponent } from './secure/dashboard/dashboard.component';
import { AdminAccountComponent } from './secure/admin/admin-account/admin-account.component';
import { AdminSubscriberListUploadsComponent } from './secure/admin/admin-subscriber-list-uploads/admin-subscriber-list-uploads.component';
import { SubscribersListComponent } from './secure/admin/subscribers-list/subscribers-list.component';
import { SubscriberInfoComponent } from './secure/admin/subscriber-info/subscriber-info.component';
import { AdminEventImagesComponent } from './secure/admin/admin-event-images/admin-event-images.component';
import { AdminSubscriberUploadsComponent } from './secure/admin/admin-subscriber-uploads/admin-subscriber-uploads.component';
import { agencySecureHomeComponent } from './secure/agency/agency-secure-home/agency-secure-home.component';
import { AgencyHomeEventImagesComponent } from './public/agency-home-event-images/agency-home-event-images.component';
import { AgencyHomeComponent } from './public/agency-home/agency-home.component';

const homeRoutes: Routes = [
    {
        path: '',
        redirectTo: '/',
        pathMatch: 'full'
    },
    {
        path: '',
        component: HomeComponent,
        children: [
            {path: '', component: HomeLandingComponent},
            {path: 'about', component: AboutComponent},
            {path: 'login', component: LoginComponent},
            {path: 'register', component: RegisterComponent},
            {path: 'confirmRegistration/:username', component: RegistrationConfirmationComponent},
            {path: 'resendCode', component: ResendCodeComponent},
            {path: 'forgotPassword/:email', component: ForgotPassword2Component},
            {path: 'forgotPassword', component: ForgotPasswordStep1Component},
            {path: 'newPassword', component: NewPasswordComponent}
        ]
    },
];

const secureHomeRoutes: Routes = [
    {
        path: '',
        redirectTo: '/',
        pathMatch: 'full'
    },
    {
        path: '', component: SecureHomeComponent, children: [
        {path: 'logout', component: LogoutComponent},
        {path: 'jwttokens', component: JwtComponent},
        {path: 'upload', component: UploadComponent},
        {path: 'plan', component: SubscribePlanComponent},
        {path: 'subscribeinfo', component: SubscribeComponent},
        {path: ':securelogin', component: agencyComponent,
        children: [
            {
                path: '',
                redirectTo: 'home',
                pathMatch: 'full'
            },
            {path: 'home', component: AgencyHomeComponent},
            {path: 'events/:id', component: AgencyHomeEventImagesComponent},
            {path: 'homecontrols', component: agencySecureHomeComponent},
            {path: 'plan', component: SubscribePlanComponent},
            {path: 'dashboard', component: DashboardComponent},
            {path: 'photos', component: MyphotoComponent},
            {path: 'agency-account', component: AgencyAccountComponent},
            /* {path: 'events', component: EventListComponent}, NOT IN USE */
            {path: 'subscription-plans', component: SubscribePlanComponent},
            {path: 'dashboard2', component: IndexPostSubscriptionFreeComponent},
            {path: 'dashboard3', component: IndexPostSubscriptionPremiumComponent},
            {path: 'free-subscription-info', component: FreeSubscriptionInfoComponent},
            {path: 'premium-subscription-info', component: PremiumSubscriptionInfoComponent},
            {path: 'agency-event/:id', component: UploadComponent},
            {path: 'admin-account', component: AdminAccountComponent},
            {path: 'admin-subscriber-list-uploads', component: AdminSubscriberListUploadsComponent},
            {path: 'subscribers', component: SubscribersListComponent},
            {path: 'subscribers-uploads/:id', component: AdminSubscriberUploadsComponent},
            {path: 'subscribers/:id', component: SubscriberInfoComponent},
            {path: 'admin-event/:id', component: AdminEventImagesComponent}] 
        }]
    }    
];

const routes: Routes = [
    {
        path: '',
        children: [
            ...homeRoutes,
            ...secureHomeRoutes,
            {
                path: '',
                component: HomeComponent
            }
        ]
    },


];

export const appRoutingProviders: any[] = [];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
// routing with param.
// https://www.youtube.com/watch?v=2HWMx8-06Ac
