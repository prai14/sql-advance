import { TestBed, inject } from '@angular/core/testing';

import { Ddb.UserService } from './ddb.user.service';

describe('Ddb.UserService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Ddb.UserService]
    });
  });

  it('should be created', inject([Ddb.UserService], (service: Ddb.UserService) => {
    expect(service).toBeTruthy();
  }));
});
