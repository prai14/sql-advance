import { Error } from 'aws-sdk/clients/stepfunctions';
import { AdminService } from './sql-db/admin.service';
import { IBaseComponent } from '../shared/base.component';
import { ApiControllerService } from './api-controller.service';
import { ISubscriberPage } from '../models/subscriber-page-info';
const camelcaseKeys = require('camelcase-keys');
import { isNullOrUndefined } from 'util';
import { IEvent } from '../models/event';
import { ISubscriber, Subscriber } from '../models/subscriber';
import { IUser } from '../models/user';
import { IImage } from '../models/image-info';
import { UserLoginService } from './user-login.service';
import { Injectable } from '@angular/core';
import { UserService } from '../service/sql-db/user.service';
import { SubscriberService } from './sql-db/subscriber.service';
import { ImageService } from './sql-db/image.service';


@Injectable()
export class InitAppService {

  constructor(public userLoginService: UserLoginService, 
    public userService: UserService,
    public adminService: AdminService,
    public subscriberService: SubscriberService,
    public imageService: ImageService,
  public apiController: ApiControllerService ) { }

  loadAllUsers(callback ) {
    this.adminService.getALLUsers().subscribe(userList => {
      console.log(userList);
      AdminService.allUsers = userList.map(x => camelcaseKeys(x));
      console.log(AdminService.allUsers);
      callback();
    });
  }

  loadLatestUsers(callback: Function ) {
    this.adminService.getLatsteUsers().subscribe(userList => {
      AdminService.latestUsers = userList.map(x => camelcaseKeys(x));
      callback();
    });
  }

  loadUserOnly(name:  string, callback: Function ) {
    console.log('load Only User Data start :: ', name);

    if (isNullOrUndefined(UserService.selectedUser)) {
      this.apiController.getByUname(name).subscribe(data => {
      UserService.selectedUser = camelcaseKeys(data[0]);
      console.log('load Only User Data End');
      console.log(UserService.selectedUser);
      callback(null, UserService.selectedUser);
      return;
    });
    } else {
      callback(null, UserService.selectedUser);
    }
  }


    loadUser(name:  string, callback: Function ) {
      console.log('load Only User Data start :: ', name);

      if (isNullOrUndefined(UserService.selectedUser)) {
        this.apiController.getByUname(name).subscribe(data => {
        UserService.selectedUser = camelcaseKeys(data[0]);
        console.log('load Only User Data End');
        console.log(UserService.selectedUser);
        
        callback(null, UserService.selectedUser);
          return;
        });
      } else {
        callback(null, UserService.selectedUser);
      }
    }

    loadImages(eventId: number, callback: Function ) {
      const user = UserService.selectedUser;
      if (isNullOrUndefined(user)) {
          callback();
          return;
      }
      console.log('loading images for event : ' + eventId);
      if (isNullOrUndefined(ImageService.imageList)) {
          this.imageService.getImagesByEventId(user.id, eventId, () => {
          console.log('loaded images for event : ' + eventId);
          callback();
          return;
        });
      }
      callback();
    }

    loadEvents(callback: Function ) {
      const user = UserService.selectedUser;
      if (isNullOrUndefined(user)) {
          callback();
          return;
      }
        console.log('loading events');

        if (isNullOrUndefined(ImageService.eventList)) {
        this.imageService.loadEvents(user.id, () => {
          console.log('loaded events');
          callback();
          return;
        });
        callback();
      }
    }

    loadSubscriber(callback: Function ) {
      const user = UserService.selectedUser;
      if (!isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
        callback();
        return;
      }
      this.loadSubscriberBase(user, callback);
    }

    loadSubscriberBase(user: IUser, callback: Function ) {
      if (isNullOrUndefined(user)) {
          callback();
          return;
      }

     // console.log('loading subscriber info', subscriberId);
      this.subscriberService.loadSubscriber(user.id, user.subscriberId, (err, data) => {
       // console.log('loaded events for event : ' + eventId);
       user.subscriber = data;
        callback(err, data);
      });
    }

    loadSubscriberHome(callback: Function ) {
      const user = UserService.selectedUser;
      this.loadSubscriberHomeBase(user, callback);
    }

    loadSubscriberHomeBase(user: IUser, callback: Function ) {
      //const user = UserService.selectedUser;
      if (isNullOrUndefined(user)) {
          callback();
          return;
      }

      const subscriberInfo = SubscriberService.userSubscriberInfo;
      if (isNullOrUndefined(subscriberInfo)) {
          callback();
          return;
      }

      if (!isNullOrUndefined(SubscriberService.userSubscriberInfo.subscriberPage)) {
        callback();
        return;
      }
      console.log('loading  subscriberInfo.subsubscriber info', subscriberInfo.id);
      this.subscriberService.loadSubscriberHome(user.id, user.subscriberId, 
        subscriberInfo.subscriberPageId, () => {
        console.log('loaded subscriber page for subscriber : ' + subscriberInfo.id);
        callback();
      });
    }

    loadSubscriberDetails(callback: Function ) {
      const user = UserService.selectedUser;
      if (isNullOrUndefined(user)) {
          callback();
          return;
      }

      const subscriberInfo = SubscriberService.userSubscriberInfo;
      if (isNullOrUndefined(subscriberInfo)) {
          callback();
          return;
      }

      console.log('loading  subscriberInfo.subscriber details', subscriberInfo.id);
      this.subscriberService.loadSubscriberHome(user.id, user.subscriberId,
        subscriberInfo.subscriberPageId, () => {
        console.log('loaded subscriber page for subscriber : ' + subscriberInfo.id);
        callback();
      });
    }

    public loadAllData(name: string, eventId: number, comp: IBaseComponent ) {
      this.loadUser(name, (err, data) => {
        comp.onLoadUser(err, data);
        this.loadImages(eventId, (err1, data1) => {
          comp.onLoadImage(err1, data1);
        });

        this.loadEvents((err1, data1) => {
          comp.onLoadEvents(err1, data1);
        });

        this.loadSubscriber((err1, data1) => {
          comp.onLoadSubscriberInfo(err1, data1);
          this.loadSubscriberHome((err2, data2) => {
            comp.onLoadSubscriberPage(err2, data2);
          });
          this.loadSubscriberHome((err2, data2) => {
            comp.onLoadSubscriberDetails(err2, data2);
          });
        });
      });
    }
}
