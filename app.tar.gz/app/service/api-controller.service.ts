import { ISubscriberDetails } from '../models/subscriber-details';
import { ISubscriberPage } from '../models/subscriber-page-info';
const camelcaseKeys = require('camelcase-keys');
import { isNullOrUndefined } from 'util';
import { IEvent } from '../models/event';
import { ISubscriber, Subscriber } from '../models/subscriber';
import { IUser } from '../models/user';
import { IImage } from '../models/image-info';
import { UserLoginService } from './user-login.service';
import { Injectable } from '@angular/core';
import { UserService } from '../service/sql-db/user.service';
import { SubscriberService } from './sql-db/subscriber.service';
import { ImageService } from './sql-db/image.service';

@Injectable()
export class ApiControllerService {

  constructor(public userLoginService: UserLoginService, 
    public userService: UserService,
    public subscriberService: SubscriberService,
    public imageService:ImageService ) { }
 
  getUser(id: number){
    return this.userService.getUser(id);
  }
  getByUname(uname: string){
    return this.userService.getByUname(uname);
  }

  addNewUser(userData, callback: Function) {
    const newUser: IUser = {
        id: 1,
        uuid: 1212,
        email: userData.email,
        name: userData.name,
        phone: userData.phone_number,
        status: 1,
    };

    this.addUser(newUser).subscribe(data => {
        callback(null, data);
    });
  }

  addUser(user) {
    return this.userService.addUser(user); 
  }
  getUserDetail(userId: number, detailsId: number) {
    return this.userService.getUserDetail(userId, detailsId);
  }

  addUserDetail(userId: number, userDetail){
    return this.userService.addUserDetail(userId, userDetail);
  }

  getSubscriber(userId, id) {
    return this.subscriberService.getSubscriber(userId, id);
  }

  getSubscriberDetail(userId, subscriberId, id){
    return this.subscriberService.getSubscriberDetail(userId, subscriberId, id);
  }

  getSubscriberHome(userId, subscriberId, id){
    return this.subscriberService.getSubscriberHome(userId, subscriberId, id);
  }

  getSubscriberType(id){
    return this.subscriberService.getSubscriberType(id);
  }

  public saveSubscriber(type, callback) {
    if (isNullOrUndefined(SubscriberService.userSubscriberInfo) 
      || (SubscriberService.userSubscriberInfo.licenseId = 0)) {
        this.addSubscriber(type, callback);
      } else {
        this.updateSubscriber(type, callback);
    }
  } 

  addSubscriber(type, callback) {
    console.log('adding fee subscription');

    const newSubscriber: ISubscriber = new Subscriber();
    newSubscriber.licenseId = type; // 0=>not sub, 1=> free, 2+=>paid sub
    newSubscriber.useId = UserService.selectedUser.id;
    newSubscriber.duration = 3;
    console.log(newSubscriber);
    return this.subscriberService.addSubscriber(newSubscriber.useId, newSubscriber).subscribe(data => {
        UserService.selectedUser.subscriberId = data.info.insertId;
        this.userService.updateUser(UserService.selectedUser).subscribe(data1 =>{
          callback(null, data1);
        });
      });
  }

  public saveSubscriberPage(page: ISubscriberPage) {
    //if(page.id == 0){
       this.addSubscriberPage(page, (err, data) => {
           console.log('added successfully');
           document.getElementById('save').innerHTML='Save';
       });
     //  return;
    // }
 
   /*  // this.updateSubscriberPage(page, (err, data1) => {
       console.log('updated successfully');
     }); */
   }

  addSubscriberPage(page: ISubscriberPage,  callback) {
    console.log("adding subscriber page");
    console.log(page);
    this.subscriberService.addSubscriberHome(
      UserService.selectedUser.id,
      SubscriberService.userSubscriberInfo.id, 
      page).subscribe(data => {
        console.log("updated successfull");
        document.getElementById('save').innerHTML='Saved';
        console.log(data);
        SubscriberService.userSubscriberInfo.subscriberPageId = data.info.insertId;
        SubscriberService.userSubscriberInfo.subscriberPage = page;
        this.subscriberService.updateSubscriber(UserService.selectedUser.id,
          SubscriberService.userSubscriberInfo).subscribe(data1 => {
          callback(null, data1);
        });
      });
  }

  updateSubscriberPage(page: ISubscriberPage,  callback) {
    console.log('updating subscriber');
    console.log(page);
    this.subscriberService.updateSubscriberHome(
      UserService.selectedUser.id,
      SubscriberService.userSubscriberInfo.id, page).subscribe(data => {
        console.log('updated successfull');
        console.log(data);
          callback(null, data);
      });
  }

  updateSubscriber(type: number,  callback) {
    console.log('updating subscriber');
    console.log(type);
    SubscriberService.userSubscriberInfo.licenseId = type;
    // SubscriberService.userSubscriberInfo.subscriberPage = page;
    this.subscriberService.updateSubscriber(UserService.selectedUser.id,
    SubscriberService.userSubscriberInfo).subscribe(data1 => {
      callback(null, data1);
    });
  }

  addSubscriberDetails(details: ISubscriberDetails,  callback) {
    console.log("updating subscriber details");
    console.log(details);
  }

  updateSubscriberDetail(detailsId: number,  callback) {
    console.log('updating subscriber');
    console.log(detailsId);
  }

  addImage(userId: number, eventId: number, image: IImage) {
    return this.imageService.addImage(userId, eventId, image);
  }

  addEvent(userId: number, event: IEvent) {
    return this.imageService.addEvent(userId, event);
  }

  getUserName(): string {
    return this.userLoginService.getUserName();
  }

  getSelectedUser(): IUser {
    return UserService.selectedUser;
  }

  getSubscriberInfo(): ISubscriber {
    return SubscriberService.userSubscriberInfo;
  }


  log(fileName?: string, functionName?: string,  data?: any): void {
    console.log(fileName, + '::' + functionName + '::', data);
  }
  public loadImageAndSubscriberInfo(userId: number, subscriberId: number, callBack) {
    this.loaSubscriberInfo(userId, subscriberId, () => {
    this.imageService.getEventMap(userId, callBack);
    });
  }

  public loaSubscriberInfo(userId: number, subscriberId: number, callBack) {
    if (isNullOrUndefined(subscriberId) || subscriberId < 1 || userId < 1) {
      console.log('user is not subscribe yet');
      callBack();
      return;
    }

    if(isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
      console.log('loading subscriber info', subscriberId);
      this.subscriberService.getSubscriber(userId, subscriberId).subscribe(subscriberInfo => {
        const obj = subscriberInfo[0];
        if (obj == null) {
          console.log('user is not subscribe yet');
          callBack();
          return;
        }

        SubscriberService.userSubscriberInfo = camelcaseKeys(subscriberInfo[0]);
        console.log('SubscriberService.userSubscriberInfo');
        console.log(SubscriberService.userSubscriberInfo);

        this.subscriberService.getSubscriberHome(
          UserService.selectedUser.id,
          SubscriberService.userSubscriberInfo.id,
          SubscriberService.userSubscriberInfo.subscriberPageId).
        subscribe(page => {
          console.log(page);
          if ( !isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
            SubscriberService.userSubscriberInfo.subscriberPage = camelcaseKeys(page[0])
          }
          console.log('subscribe page success');
          console.log(SubscriberService.userSubscriberInfo.subscriberPage);
          callBack();
        });
      });
    } else {
      callBack();
    }
  }


  public loadAllSubscriberInfo(userId: number, subscriberId: number, callBack) {
    if (isNullOrUndefined(subscriberId) || subscriberId < 1 || userId < 1) {
      console.log('user is not subscribe yet');
      callBack();
      return;
    }

    if(isNullOrUndefined(SubscriberService.userSubscriberInfo)) {
      console.log('loading subscriber info', subscriberId);
      this.subscriberService.getSubscriber(userId, subscriberId).subscribe(subscriberInfo => {
        const obj = subscriberInfo[0];
        if (obj == null) {
          console.log('user is not subscribe yet');
          callBack();
          return;
        }

        SubscriberService.userSubscriberInfo = camelcaseKeys(subscriberInfo[0]);
        console.log('SubscriberService.userSubscriberInfo');
        console.log(SubscriberService.userSubscriberInfo);

        this.subscriberService.getSubscriberHome(
          UserService.selectedUser.id,
          SubscriberService.userSubscriberInfo.id,
          SubscriberService.userSubscriberInfo.subscriberPageId).
        subscribe(page => {
          SubscriberService.userSubscriberInfo.subscriberPage = camelcaseKeys(page[0]);           
          console.log('subscribe page success');
          console.log(SubscriberService.userSubscriberInfo.subscriberPage);
          //callBack();
        });
      });
    } else {
      // callBack();
    }
  }

  loadUserInfo(name:  string, callback: Function ) {
    this.loadAllUserInfo(name, callback);
  }
  loadAllUserInfo(name:  string, callback: Function ) {
    if (isNullOrUndefined(UserService.selectedUser)) {
      this.getByUname(name).subscribe(data => {
          UserService.selectedUser = camelcaseKeys(data[0]);
          if (isNullOrUndefined(UserService.selectedUser)) {
            callback();
            return 'user does not found in db';
          }

          this.loadImageAndSubscriberInfo(
            UserService.selectedUser.id,
            UserService.selectedUser.subscriberId,
            () =>{
              callback();
            }
          );
      });
    } else {
      this.loadImageAndSubscriberInfo(
        UserService.selectedUser.id,
        UserService.selectedUser.subscriberId, 
        () =>{
          callback();
        }
      );
    }
  }

  loadUserAndSubscriberInfo(name:  string, callback: Function ) {
    if (isNullOrUndefined(UserService.selectedUser)) {
      this.getByUname(name).subscribe(data => {
          UserService.selectedUser = camelcaseKeys(data[0]);
          if (isNullOrUndefined(UserService.selectedUser)) {
            callback();
            return 'user does not found in db';
          }

          this.loadAllSubscriberInfo(UserService.selectedUser.id,
            UserService.selectedUser.subscriberId, () => {
            callback();
            });
      });
    } else {
      this.loadAllSubscriberInfo(UserService.selectedUser.id,
        UserService.selectedUser.subscriberId, () => {
        callback();
        });
    }
  }

  loadUserAndEventInfo(name:  string, eventId: number, callback: Function ) {
    if (isNullOrUndefined(UserService.selectedUser)) {
      this.getByUname(name).subscribe(data => {
          UserService.selectedUser = camelcaseKeys(data[0]);
          if (isNullOrUndefined(UserService.selectedUser)) {
            callback();
            return 'user does not found in db';
          }

          this.imageService.getImagesByEventId(
              UserService.selectedUser.id,
              eventId,
              callback );
      });
    } else {
      this.imageService.getImagesByEventId(
        UserService.selectedUser.id,
        eventId,
        callback );
    }
  }
}
