export class ApiConstant {
  // this has constant url
  public static USER_BASE_URL = 'https://l7b177dvl0.execute-api.us-east-1.amazonaws.com/dev/api/v1/';
  public static IMAGE_BASE_URL= ' https://d5q8jgqtpg.execute-api.us-east-1.amazonaws.com/dev/api/v1/';
  public static SUBSCRIBER_BASE_URL= 'https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/';
  public static ADMIN_BASE_URL= 'https://si5kgpo74k.execute-api.us-east-1.amazonaws.com/dev/api/v1/';

  public static GET_ALL_USERS_URL = ApiConstant.ADMIN_BASE_URL + 'users/all';
  public static GET_LATEST_USERS_URL = ApiConstant.ADMIN_BASE_URL + 'users/latest/5';

  public static GET_USER_URL = ApiConstant.USER_BASE_URL + 'users/{userId}';

  public static GET_BY_UNAME = ApiConstant.USER_BASE_URL + 'users/names/';

  public static POST_USER_URL = ApiConstant.USER_BASE_URL + 'users/';
  public static GET_USER_DETAIL_URL = ApiConstant.USER_BASE_URL + 'users/{userId}/details/{userDetailsId}';
  public static POST_USER_DETAIL_URL = ApiConstant.USER_BASE_URL + 'users/{userId}/details/';
  public static GET_IMAGE_URL = ApiConstant.IMAGE_BASE_URL + 'users/{userId}/events/{eventId}/images/';
  public static GET_ALL_IMAGES_PER_EVENT = ApiConstant.IMAGE_BASE_URL + 'users/1/events/2/images/';
  public static GET_ALL_EVENTS_PER_USER = ApiConstant.IMAGE_BASE_URL + 'users/1/events/';
  public static GET_EVENT_URL = ApiConstant.IMAGE_BASE_URL + 'users/{userId}/events/{eventId}';
  public static POST_IMAGE_URL = ApiConstant.IMAGE_BASE_URL + 'users/{userId}/events/{eventId}/images/';
  public static POST_EVENT_URL = ApiConstant.IMAGE_BASE_URL + 'users/{userId}/events/ ';
  public static GET_SUBSCRIBER_URL = ApiConstant.SUBSCRIBER_BASE_URL + 'users/{userId}/subscribers/';
  public static GET_SUBSCRIBER_DETAIL_URL = ApiConstant.SUBSCRIBER_BASE_URL + 'users/{userId}/subscribers/{subscriberId}/details/';
  public static GET_SUBSCRIBER_HOME_URL = ApiConstant.SUBSCRIBER_BASE_URL + 'users/{userId}/subscribers/{subscriberId}/pages/';
  public static GET_SUBS_TYPE_URL = ApiConstant.SUBSCRIBER_BASE_URL + 'users/{userId}/subscribers/{subscriberId}/subscriptions/';
  public static POST_SUBSCRIBER_URL = ApiConstant.SUBSCRIBER_BASE_URL + 'users/{userId}/subscribers/';
  public static POST_SUBSCRIBER_DETAIL_URL = ApiConstant.SUBSCRIBER_BASE_URL + 'users/{userId}/subscribers/{subscriberId}/details/';
  public static POST_SUBSCRIBER_HOME_URL = ApiConstant.SUBSCRIBER_BASE_URL + 'users/{userId}/subscribers/{subscriberId}/pages/';
  public static POST_SUBS_TYPE_URL = ApiConstant.SUBSCRIBER_BASE_URL + 'users/{userId}/subscribers/{subscriberId}/subscriptions/';
}

  /*POST - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events

  PUT - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events

  DELETE - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}

  GET - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}

  POST - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images

  PUT - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images

  DELETE - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images/{imageId}

  GET - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images/{imageId}





 POST - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers

  PUT - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers

  DELETE - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}

  GET - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}

  POST - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/details

  PUT - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/details

  DELETE - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/details/{detailsId}

  GET - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/details/{detailsId}

  POST - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/pages

  PUT - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/pages

  DELETE - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/pages/{pageId}

  GET - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/pages/{pageId}

  POST - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/subscriptions

  PUT - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/subscriptions

  DELETE - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/subscriptions/{subscriptionId}

  GET - https://ierazbs6ti.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/subscribers/{subscriberId}/subscriptions/{subscriptionId}



https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/1/events/2/images/



 POST - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events

 PUT - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events

 DELETE - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}

 GET - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}

 GET - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events

 POST - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images

 PUT - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images

 DELETE - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images/{imageId}

 GET - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images/{imageId}

 GET - https://79cx92gz5l.execute-api.us-east-1.amazonaws.com/dev/api/v1/users/{userId}/events/{eventId}/images */