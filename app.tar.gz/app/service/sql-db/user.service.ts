import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators';
import { IUser, User } from '../../models/user';
import { IUserDetails } from '../../models/user-details';
import { HttpErrorHandler, HandleError } from './http-error-handler.service';
import {ApiConstant} from './apiConstant';
import { UserLoginService } from '../user-login.service';



@Injectable()
export class UserService {

  public static selectedUser: IUser;

  constructor(
    private http: HttpClient) { }

    public getUser(id: number): Observable<any>{
    return this.http.get(ApiConstant.GET_USER_URL + id);
  }

  public getByUname(uname: string): Observable<any> {

    return this.http.get(
      ApiConstant.GET_BY_UNAME + uname);
  }

  addUser(user: IUser): Observable<any> {

    return this.http.post<IUser>(
      ApiConstant.USER_BASE_URL + 'users/', user);
  }

  public getUserDetail(userId: number, detailsId: number): Observable<IUserDetails[]> {

    return this.http.get<IUserDetails[]>(
      ApiConstant.USER_BASE_URL + 'users/' + userId + '/details/' +
      detailsId);
  }

  addUserDetail(userId: number, userDetail: IUserDetails): Observable<IUserDetails> {

    return this.http.post<IUserDetails>(
      ApiConstant.USER_BASE_URL + 'users/' + userId + '/details/',
      userDetail);
  }

  updateUser(user: IUser): Observable<any> {
    console.log(user);
    return this.http.put<IUser>(
      ApiConstant.USER_BASE_URL + 'users/',  user);
  }

}
