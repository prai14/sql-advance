import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators';
import { IUser, User } from '../../models/user';
import { IUserDetails } from '../../models/user-details';
import { HttpErrorHandler, HandleError } from './http-error-handler.service';
import {ApiConstant} from './apiConstant';


@Injectable()
export class AdminService {

  public static allUsers: IUser[];
  public static latestUsers: IUser[];

  constructor(
    private http: HttpClient) { }

  public getALLUsers(): Observable<any> {
    return this.http.get(ApiConstant.GET_ALL_USERS_URL);
  }

  public getLatsteUsers(): Observable<any> {
    return this.http.get(ApiConstant.GET_LATEST_USERS_URL);
  }
}