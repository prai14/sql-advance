const camelcaseKeys = require('camelcase-keys');
import { UserLoginService } from '../user-login.service';
import { Callback } from '../cognito.service';
import { S3Service } from '../s3.service';
import { ApiControllerService } from '../api-controller.service';
import { UserService } from './user.service';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IImage, ImageInfo } from '../../models/image-info';
import { IEvent } from '../../models/event';
import { Observable } from 'rxjs/Observable';
import {ApiConstant} from './apiConstant';
import * as S3 from 'aws-sdk/clients/s3';
const uuidv4 = require('uuid/v4');
import { TSMap } from 'typescript-map';


@Injectable()
export class ImageService {

  public static eventMap = new TSMap<number, IEvent>();
  public static image: ImageInfo; 
  public static eventList: IEvent[];
  public static imageList: IImage[];
  constructor(private http: HttpClient,
  private userService: UserService,
  private s3Service: S3Service,
  private userLoginService: UserLoginService) { }

  uploadPhoto( userId: number, eventId: number, file: File, callBack: Function) {
    console.log('uploading file one by one');
    const self = this;
    const uuid = uuidv4();
    const extention = file.name.split('.').pop();
    const fileName = uuid + '.' + extention;

    self.s3Service.addPhoto(fileName, file, this.userLoginService.getUserName(), '' + eventId, (err, data) => {
      if (err) {
        callBack(err, data);
        return;
      }

      const imageInfo: S3.ManagedUpload.SendData = data;
      const imageData: IImage = {
        'id': 1,
        'version': 1,
        'fileDescriptor': '',
        'url': imageInfo.Location,
        'bucket': imageInfo.Bucket,
        'key': imageInfo.Key,
        'userId': UserService.selectedUser.id,
        'folderId': eventId,
        'displayName': file.name,
        'name': file.name,
        'type': 1,
        'mimeType': file.type,
        'modifierId': UserService.selectedUser.id
      };

      console.log(imageData);
      this.addImage(userId, eventId, imageData).subscribe(callBack(null, camelcaseKeys(data),imageData)) ;
    });
  }

  uploadAssets( userId: number, file: File, callBack: Function) {
    console.log('uploading file one by one');
    const self = this;
    const uuid = uuidv4();
    const extention = file.name.split('.').pop();
    const fileName = uuid + '.' + extention;

    self.s3Service.addAssets(fileName, file, this.userLoginService.getUserName(), (err, data) => {

      if (err) {
        callBack(err, data);
        return;
      }
      callBack(err, data);
    });
  }
  

  public getImage(userId: number, eventId: number, imageId: number): Observable<any> {
    return this.http.get<ImageInfo[]>(
      ApiConstant.IMAGE_BASE_URL + 'users/' +
      userId + '/events/' + eventId + '/images/' + imageId);
  }

  addImage(userId: number, eventId: number, imageInfo: ImageInfo): Observable<any> {
    return this.http.post<IImage>(
      ApiConstant.IMAGE_BASE_URL + 'users/' +
      userId + '/events/' + eventId + '/images/', imageInfo);
  }
  public getEvent(userId: number, eventId: number): Observable<any> {
    return this.http.get<IEvent[]>(
      ApiConstant.IMAGE_BASE_URL + 'users/' + userId + '/events/' + eventId);
  }

  addEvent(userId: number, event: IEvent): Observable<any> {
    return this.http.post<Event>(
      ApiConstant.IMAGE_BASE_URL + 'users/' + userId + '/events/', event);
  }

  public getEvents(userId: number): Observable<any> {
    return this.http.get<Event[]>(
      ApiConstant.IMAGE_BASE_URL + 'users/' + userId + '/events/');
  }

  public getImages(userId: number, eventId: number): Observable<any> {
    return this.http.get<IImage[]>(
      ApiConstant.IMAGE_BASE_URL + 'users/' + userId + '/events/' + eventId + '/images/');
  }

  public getEventMap(userId: number, callback: Function) {
    const selfEvent = this;
    this.getEvents(userId).subscribe(data => {
      //console.log(data);
      const selfImage = selfEvent;
      //console.log(data);
      data.map(x => camelcaseKeys(x));
      ImageService.eventList = data;
      selfEvent.getParentImage(userId, callback);

      data.forEach(element => {
        ImageService.eventMap.set(element.id, element);
        selfImage.getImages(userId, element.id).subscribe(imageList => {
            imageList.map(x => camelcaseKeys(x));
            element.imageList = imageList;
            selfImage.updateThumbnailImage(imageList);
        });
      });
    });
  }

  public loadEvents(userId: number, callback: Function) {
    const selfEvent = this;
    this.getEvents(userId).subscribe(data => {
      console.log(data);
      const selfImage = selfEvent;
      console.log(data);
      data.map(x => camelcaseKeys(x));
      ImageService.eventList = data;
      callback();
    });
  }

   getParentImage(userId: number, callback: Function) {
    this.getImagesByEventId(userId, 0, callback);
   }

   getImagesByEventId(userId: number, eventId: number, callback: Function) {
    console.log('methos-in:getParentImage');
    this.getImages(userId, eventId).subscribe(imageList => {
   //     console.log(imageList);
        ImageService.imageList = imageList.map(x => camelcaseKeys(x));
     //   console.log(ImageService.imageList);

        if(typeof ImageService.imageList === 'undefined' && ImageService.imageList == null) {
          console.log('no image found');
          callback();
          return; 
        }
        this.updateThumbnailImage(ImageService.imageList);
        //console.log(ImageService.imageList);
        callback();
    });
  }

  updateThumbnailImage(imageList) {

    if(typeof imageList === 'undefined' && imageList == null) {
      console.log('no image found');
      return; 
    }

    //console.log(typeof imageList);

    const length = imageList.length;
    //console.log(length);
    for (let index = 0; index < length; index++) {
      const element = imageList[index];
      this.updateThumbnail(element);
    }
  }

  public updateThumbnail(element) {
    if(typeof element.url !== 'undefined' && element.url !== null) {
      const match = 'https://phototainment-userfiles-mobilehub-1424088883.s3.amazonaws.com';
      element.thumbnail = element.url.replace(match, match + '/thumbnails');
      element.thumbnail = element.thumbnail.substring(0, element.thumbnail.lastIndexOf('.') + 1) + 'jpg';
    }
  }
}
