import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { ISubscriber, Subscriber } from '../../models/subscriber';
import {ApiConstant} from './apiConstant';
import { ISubscriberPage } from '../../models/subscriber-page-info';
import { ISubscription } from '../../models/subscription-type';

const camelcaseKeys = require('camelcase-keys');


@Injectable()
export class SubscriberService {

  public static userSubscriberInfo: ISubscriber;


  constructor(private http: HttpClient) { }
 public getSubscriber(userId: number, id: number): Observable<Subscriber[]> {
    return this.http.get<any>(ApiConstant.SUBSCRIBER_BASE_URL +
      'users/' + userId + '/subscribers/' + id);
  }

  addSubscriber(userId: number, subscriber: ISubscriber): Observable<any> {
    return this.http.post<Subscriber>(ApiConstant.SUBSCRIBER_BASE_URL + 
      'users/' + userId + '/subscribers/', subscriber);
  }

  updateSubscriber(userId: number, subscriber: ISubscriber): Observable<any> {
    return this.http.put<ISubscriber>(ApiConstant.SUBSCRIBER_BASE_URL + 
      'users/' + userId + '/subscribers/', subscriber);
  }

  public getSubscriberDetail(userId: number, subscriberId: number, id: number): Observable<Subscriber[]> {
    return this.http.get<Subscriber[]>(ApiConstant.SUBSCRIBER_BASE_URL +
      'users/' + userId + '/subscribers/' + subscriberId + '/details/' + id);
  }

  addSubscriberDetail(userId: number, subscriberId: number, subscriber: ISubscriber): Observable<any> {
    return this.http.post<ISubscriber>(
      ApiConstant.SUBSCRIBER_BASE_URL + 
      'users/' + userId + '/subscribers/' + subscriberId + 
      '/details/', subscriber);
  }

  public getSubscriberHome(userId: number, subscriberId: number, id: number): Observable<any> {
    return this.http.get<any>(
      ApiConstant.SUBSCRIBER_BASE_URL +
      'users/' + userId + '/subscribers/' + subscriberId + 
      '/pages/' + id);

  }

  addSubscriberHome(userId: number, subscriberId: number, subscriber: ISubscriberPage): Observable<any> {
    return this.http.post<ISubscriberPage>(
        ApiConstant.SUBSCRIBER_BASE_URL +
        'users/' + userId + '/subscribers/' + subscriberId + 
        '/pages/', subscriber);
  }

  updateSubscriberHome(userId: number, subscriberId: number, subscriber: ISubscriberPage): Observable<any> {
    return this.http.put<ISubscriberPage>(
        ApiConstant.SUBSCRIBER_BASE_URL +
        'users/' + userId + '/subscribers/' + subscriberId + 
        '/pages/', subscriber);
  }

  public getSubscriberType(id: number): Observable<ISubscription[]> {
    return this.http.get<ISubscription[]>(ApiConstant.GET_SUBS_TYPE_URL + id);
  }

  addSubscriberType(subscriberType: ISubscription): Observable<ISubscription> {
    return this.http.post<ISubscription>(ApiConstant.POST_SUBS_TYPE_URL, subscriberType);
  }

  loadSubscriber(userId: number, subscriberId: number, callback: Function) {
    this.getSubscriber(userId, subscriberId).subscribe(subscriberInfo => {
      const obj = subscriberInfo[0];
      if (obj == null) {
        console.log('user is not subscribe yet');
        callback(new Error('user is not subscribe yet'), null);
        return;
      }
      SubscriberService.userSubscriberInfo = camelcaseKeys(subscriberInfo[0]);
      console.log('SubscriberService.userSubscriberInfo');
      console.log(SubscriberService.userSubscriberInfo);
      callback(null, SubscriberService.userSubscriberInfo);
    });
  }

  loadSubscriberHome(userId: number, subscriberId: number, pageId: number, callback: Function) {
      this.getSubscriberHome(
        userId, subscriberId, pageId).subscribe(page => {
          const obj = page[0];
          if (obj == null) {
            console.log('user has not created the page yet');
            callback(new Error('user has not created the page yet'), null);
            return;
          }
        SubscriberService.userSubscriberInfo.subscriberPage = camelcaseKeys(page[0]);
        console.log('subscribe page success');
        console.log(SubscriberService.userSubscriberInfo.subscriberPage);
        callback(null, SubscriberService.userSubscriberInfo.subscriberPage);
    });
  }

  loadSubscriberDetails(userId: number, subscriberId: number, detailId: number, callback: Function) {
    this.getSubscriberDetail(
      userId, subscriberId, detailId).subscribe(data => {
        const obj = data[0];
        if (obj == null) {
          console.log('user has not created the page yet');
          callback(new Error('user has not created the page yet'), null);
          return;
        }
     // SubscriberService.userSubscriberInfo.subscriberDetails = camelcaseKeys(data[0]);
      console.log('subscribe page success');
      console.log(SubscriberService.userSubscriberInfo.subscriberPage);
      callback(null, 'success');
    });
  }
}
