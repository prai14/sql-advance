import { TestBed, inject } from '@angular/core/testing';

import { ApiControllerService } from './api-controller.service';

describe('ApiControllerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiControllerService]
    });
  });

  it('should be created', inject([ApiControllerService], (service: ApiControllerService) => {
    expect(service).toBeTruthy();
  }));
});
