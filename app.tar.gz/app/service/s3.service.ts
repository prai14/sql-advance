import { phoneNumber } from 'aws-sdk/clients/importexport';
import { Injectable } from '@angular/core';
import {environment} from "../../environments/environment";
import {CognitoUtil} from "./cognito.service";
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3';
@Injectable()
export class S3Service {

    constructor(public cognitoUtil: CognitoUtil) {

    }

    public getS3(): S3 {
        AWS.config.update({
            region: environment.bucketRegion,
        });

        const clientParams: any = {
            region: environment.bucketRegion,
            apiVersion: '2006-03-01',
            params: {Bucket: environment.bucket}
        };
        if (environment.s3_endpoint) {
            clientParams.endpoint = environment.s3_endpoint;
        }
        const s3 = new S3(clientParams);

        return s3;
    }

    public addPhoto(fileName: string, selectedFile: File, albumName: string, eventId: string, callback: Function ): boolean {
        if (!selectedFile) {
            console.log('Please choose a file to upload first.');
            return;
        }
       // const fileName: string  = selectedFile.name;
        const albumPhotosKey: string = albumName + '/' + 'upload' + '/' + eventId + '/';
        const photoKey: string = albumPhotosKey + fileName;

        this.getS3().upload( this.newFunction(photoKey, selectedFile), function (err, data) {
            callback(err, data);
            if (err) {
                console.log('There was an error uploading your photo: ', err);
                return false;
            }
            console.log(data);
            console.log('Successfully uploaded photo.');
            return true;
        });
    }

    public addAssets(fileName: string, selectedFile: File, albumName: string, callback: Function ): boolean {
        if (!selectedFile) {
            console.log('Please choose a file to upload first.');
            return;
        }
       // const fileName: string  = selectedFile.name;
        const albumPhotosKey: string = albumName + '/' + 'assets' + '/';
        const photoKey: string = albumPhotosKey + fileName;

        this.getS3().upload( this.newFunction(photoKey, selectedFile), function (err, data) {
            callback(err, data);
            if (err) {
                console.log('There was an error uploading your photo: ', err);
                return false;
            }
            console.log(data);
            console.log('Successfully uploaded photo.');
            return true;
        });
    }

    private newFunction(photoKey: string, selectedFile: File): S3.PutObjectRequest {
        console.log(photoKey);
        const s3Request: S3.PutObjectRequest = {
            Key: photoKey,
            ContentType: selectedFile.type ,
            Body: selectedFile,
            StorageClass: 'STANDARD',
            ACL: 'private',
            Bucket: environment.bucket
        };

        return s3Request;
    }

    private deleteObjectRequest(photoKey: string): S3.DeleteObjectRequest {
        console.log(photoKey);
        const s3DeleteRequest: S3.DeleteObjectRequest = {
            Key: photoKey,
            Bucket: environment.bucket
        };

        return s3DeleteRequest;
    }

    private listObjectRequest(photoKey: string): S3.ListObjectsRequest {
        console.log(photoKey);
        const s3DeleteRequest: S3.ListObjectsRequest = {
            Prefix: photoKey,
            Bucket: environment.bucket
        };

        return s3DeleteRequest;
    }

    public deletePhoto(albumName, photoKey) {
        this.getS3().deleteObject(this.deleteObjectRequest(photoKey), function (err, data) {
            if (err) {
                console.log('There was an error deleting your photo: ', err.message);
                return;
            }
            console.log('Successfully deleted photo.');
        });
    }

    public listAlbums() {
        this.getS3().listObjects({Delimiter: '/', Bucket: environment.bucket}, function(err, data) {
        if (err) {
            return alert('There was an error listing your albums: ' + err.message);
        } else {
            const albums = data.CommonPrefixes.map(function(commonPrefix) {
                const prefix = commonPrefix.Prefix;
                const albumName = decodeURIComponent(prefix.replace('/', ''));
                console.log(albumName);
            });
        }
        });
    }


    public createAlbumCallBack(err, data, albumName) {
        AWS.config.update({
            region: environment.bucketRegion,
        });

        const clientParams: any = {
            region: environment.bucketRegion,
            apiVersion: '2006-03-01',
            params: {Bucket: environment.bucket}
        };
        if (environment.s3_endpoint) {
            clientParams.endpoint = environment.s3_endpoint;
        }
        const s3 = new S3(clientParams);
        if (!err) {
            return alert('Album already exists.');
        }
        const albumKey = encodeURIComponent(albumName) + '/';
        
        s3.putObject({Key: albumKey, Bucket: environment.bucket}, function(err, data) {
            if (err) {
                return alert('There was an error creating your album: ' + err.message);
            }
            console.log('Successfully created album.');
            //this.viewAlbum(albumName);
        });
    }

    public createNewAlbum(albumName: string) {
        this.createAlbum(albumName, this.createAlbumCallBack);
    }
    
    private createAlbum(albumName: string, callback) {
        albumName = albumName.trim();
        if (!albumName) {
            return alert('Album names must contain at least one non-space character.');
        }
        if (albumName.indexOf('/') !== -1) {
            return alert('Album names cannot contain slashes.');
        }
        const albumKey = encodeURIComponent(albumName) + '/';
        this.getS3().headObject({Key: albumKey, Bucket: environment.bucket},    function(err, data) {
            callback(err, data, albumName);
        });
    }

    public viewAlbum(albumName) {
        const albumPhotosKey = encodeURIComponent(albumName);
        this.getS3().listObjects({Prefix: albumPhotosKey, Bucket: environment.bucket}, function(err, data) {
            if (err) {
                return alert('There was an error viewing your album: ' + err.message);
            }
            // `this` references the AWS.Response instance that represents the response
            console.log(data);
            const href = this.request.httpRequest.endpoint.href;
            const bucketUrl = href + environment.bucket + '/';
            const photos = data.Contents.map(function(photo) {
                const photoKey = photo.Key;
                const photoUrl = bucketUrl + encodeURIComponent(photoKey);
                console.log(photoUrl);
            });
        });
    }

}
