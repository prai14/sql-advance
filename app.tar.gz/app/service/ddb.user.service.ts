import { Injectable } from '@angular/core';
import {CognitoUtil} from './cognito.service';
import {environment} from '../../environments/environment';

import * as AWS from 'aws-sdk/global';
import * as DynamoDB from 'aws-sdk/clients/dynamodb';


@Injectable()
export class UserService {
  constructor(public cognitoUtil: CognitoUtil) {
    console.log('DynamoDBUserService: constructor');
  }

  getAWS() {
    return AWS;
  }

  readUploadedImagesItemByImageId(imageId, callback) {
    console.log('DynamoDBService: reading from DDB with creds - ' + AWS.config.credentials);
    const params = {
      TableName: environment.ddbUploadImageTableName,
        Key: {
          'id': imageId,
        }
    };
    const clientParams: any = {};
    if (environment.dynamodb_endpoint) {
        clientParams.endpoint = environment.dynamodb_endpoint;
    }
    const docClient = new DynamoDB.DocumentClient(clientParams);

    docClient.get(params, function(err, data) {
      if (err) {
        console.log('Unable to read item: ' + '\n' + JSON.stringify(err, undefined, 2));
        callback( null, 'Unable to add item: ' + '\n' + JSON.stringify(err, undefined, 2)) ;
      } else {
        console.log(JSON.stringify(data, undefined, 2));
        callback(err, data);
      }
    });
  }
}
