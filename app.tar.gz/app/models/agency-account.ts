export interface IAgencyAccount {
     name?: string;
     email?: string;
     phone?: string;
     cAddress?: string;
     bAddress?:  string;
}

export class AgencyAccount implements IAgencyAccount{}

