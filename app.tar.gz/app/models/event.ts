import { IImage } from './image-info';

export interface IEvent {
    id?:  number;
    version?: number;
    parentId?: number;
    userId?: number;
    name?: string;
    description?: string;
    type?: string;
    imageList?: IImage[]; // int(4) NOT NULL, # this is for private/public/blocked/
}

export class Event implements IEvent {}
