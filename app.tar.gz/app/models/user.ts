import { ISubscriber } from './subscriber';
import { IUserDetails } from './user-details';

export interface IUser {
    id?: number;
    uuid?: number;
    email?: string;
    name?: string;
    phone?: string;
    status?: number;
    type?: number;
    createTime?:string;
    subscriberId?: number;
    subscriber?: ISubscriber;

}
export class User implements IUser {}