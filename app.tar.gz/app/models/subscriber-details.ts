import { ISubscriber } from './subscriber';
export interface ISubscriberDetails {
     id?:  number;
     version?:  number;
     cAddress?:  string;
     bAddress?:  string;
     city?:  string;
     company?:  string;
     countryCode?:  string;
     fax?:  string;
     name?:  string;
     email?:  string;
     phone?:  string;
     state?:  string;
     zip?:   string;
     addresstype?:  string;
}

export class SubscriberDetails implements ISubscriber{}

