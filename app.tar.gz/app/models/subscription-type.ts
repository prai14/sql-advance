export interface ISubscription {
    id?: number;
    version?: number;
    type?: string;
    validity?: string;
    paymentAmount?: number;
}

export class Subscription implements ISubscription { }