import { NumberResults } from "aws-sdk/clients/clouddirectory";

export interface IImage {
    id?: number;
    name?: string;
    url?: string;
    thumbnail?: string;
    eventName?: string;
    version?: number;
    fileDescriptor?: string;
    key?: string;
    bucket?: string;
    userId?: number;
    eventId?: number;
    displayName?: string;
    type?: number;          //    #this is for private / public / blocked /
    mimeType?: string;
    modifierId?: number;
    folderId?: number;
}

export class Image implements IImage {}
export class ImageInfo implements IImage {}
