export interface IPayment {
    id?:  number;
    version?:  number;
    paymentDate?:  string;
    paymentAmount?:  number;
    orderId?:  number;
    buyer?:  string;
}

export class Payment implements IPayment {}
