import { $$observable } from 'rxjs/symbol/observable';
import { IEvent } from './event';

import { ISubscriberPage } from './subscriber-page-info';
import { Subscribable } from 'rxjs/Observable';
import { ISubscriberDetails, SubscriberDetails } from './subscriber-details';
import { ISubscription } from './subscription-type';

export interface ISubscriber {
     id?: number;
     version?: number;
     licenseId?: number;
     startSubscriptionTime?: Date;
     endSubscriptionTime?: Date;
     createTime?: string;
     duration?: number;
     time?: Date;
     useId?: number;
     subscriberDetailsId?: number;
     subscriberPageId?: number;
     subscriptionTypeId?: number;
     totalSubscriber?: number;
     subscriberDetails?: ISubscriberDetails;
     subscriptionType?: ISubscription;
     subscriberPage?: ISubscriberPage;
     eventList?: Map<number, IEvent>;
    }

export class Subscriber implements ISubscriber {
}
