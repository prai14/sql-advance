export interface IUserDetails {
    id?: number;
    version?:  number;
    roleId?: number;
    providerId?: number;
    userGroupId?: number;
    profileImageId?: number;
    subscriberId?: number;
    bAddress?: string;
    cAddress?: string;
}

export class UserDetails implements IUserDetails { }