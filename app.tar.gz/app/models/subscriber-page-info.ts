import { Version } from '@angular/compiler';
export interface ISubscriberPage {
  id?: number;
  version?: number;
  title?: string;
  companyName?: string;
  contactPerson?: string;
  cAddress?: string;
  bAddress?: string;
  details?: string;
  description?: string;
  logo?: string;
  background?: string;
  eventsCount?: number;
  imagesCount?: number;
  totalEventsCount?: number;
  totalImagesCount?: number;
  noOfLicense?: number;
  startSubscriptionTime?: Date;
  createTime?: Date;
  endSubscriptionTime?: Date;
  validity?: number;
  noOfDevices?: number;
  deviceList?: string[];
  contactInfo?: string;
  headerBgType?: Number;
  headerBgPattern?: Number;
  headerBgColor?: string;
  bodyBgType?: Number;
  bodyBgImage?: string;
  bodyBgPattern?: Number;
  bodyBgColor?: string;
  logoPosition?: Number;
  headerTextColor?: string;
}

export class SubscriberPage implements ISubscriberPage { }
export class SubscriberPageInfo implements ISubscriberPage { }
