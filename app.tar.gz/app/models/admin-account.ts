export interface IAdminAccount {
   id?: number;
   name?: string;
   email?: string;
   phone?: number;
   cAddress?: string;
   bAddress?:  string;
}

export class AdminAccount implements IAdminAccount{}
